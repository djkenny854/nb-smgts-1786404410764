
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    )

    const { to, message } = await req.json()

    console.log('Sending WhatsApp message to:', to)

    // Get WhatsApp settings from database
    const { data: settings, error: settingsError } = await supabase
      .from('communication_settings')
      .select('*')
      .eq('setting_type', 'whatsapp_config')
      .eq('is_active', true)
      .single()

    if (settingsError || !settings) {
      console.error('WhatsApp settings error:', settingsError)
      throw new Error('WhatsApp provider not configured or inactive')
    }

    const config = settings.configuration
    const accessToken = config.access_token
    const phoneNumberId = config.phone_number_id

    if (!accessToken || !phoneNumberId) {
      throw new Error('WhatsApp access token or phone number ID not configured')
    }

    console.log('Using WhatsApp Phone Number ID:', phoneNumberId)

    // Send WhatsApp message using Meta Business API
    const whatsappUrl = `https://graph.facebook.com/v17.0/${phoneNumberId}/messages`
    
    const whatsappResponse = await fetch(whatsappUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: to,
        type: 'text',
        text: {
          body: message,
        },
      }),
    })

    const result = await whatsappResponse.json()

    console.log('WhatsApp API response:', JSON.stringify(result))

    if (whatsappResponse.ok) {
      console.log('WhatsApp message sent successfully:', result.messages?.[0]?.id)
      return new Response(
        JSON.stringify({ 
          success: true, 
          messageId: result.messages?.[0]?.id,
          status: 'sent' 
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    } else {
      console.error('WhatsApp API error:', result)
      throw new Error(result.error?.message || 'Failed to send WhatsApp message')
    }

  } catch (error) {
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400
      }
    )
  }
})
