
-- 1) Ensure unique per student + term in student_fees
CREATE UNIQUE INDEX IF NOT EXISTS uniq_student_fees_student_term
ON public.student_fees (student_id, academic_year, academic_term);

-- 2) Auto-assign fees to students into student_fees (unified source of truth)
CREATE OR REPLACE FUNCTION public.auto_assign_student_fees_v2()
RETURNS trigger
LANGUAGE plpgsql
AS $func$
DECLARE
  fs RECORD;
  total NUMERIC := 0;
  paid_so_far NUMERIC := 0;
BEGIN
  -- Find latest fee_structure mapped to the student's class via class_streams.full_name
  SELECT fs.*
  INTO fs
  FROM public.fee_structures fs
  JOIN public.fee_structure_classes fsc ON fsc.fee_structure_id = fs.id
  JOIN public.class_streams cs ON cs.id = fsc.class_id
  WHERE cs.full_name = NEW.class
  ORDER BY 
    fs.academic_year DESC,
    CASE fs.academic_term
      WHEN 'Term 3' THEN 3
      WHEN 'Term 2' THEN 2
      WHEN 'Term 1' THEN 1
      ELSE 0
    END DESC,
    fs.created_at DESC
  LIMIT 1;

  IF NOT FOUND THEN
    RAISE NOTICE 'No fee structure mapping found for class: %', NEW.class;
    RETURN NEW;
  END IF;

  -- Calculate total fees
  total := COALESCE(fs.tuition_fee,0)
        + COALESCE(fs.meal_fee,0)
        + COALESCE(fs.activity_fee,0)
        + COALESCE(fs.library_fee,0)
        + COALESCE(fs.computer_fee,0)
        + COALESCE(fs.medical_fee,0)
        + COALESCE(fs.development_fee,0)
        + COALESCE(fs.exam_fee,0)
        + COALESCE(fs.uniform_fee,0)
        + COALESCE(fs.misc_fee,0);

  IF NEW.boarding_status = 'Boarding' THEN
    total := total + COALESCE(fs.boarding_fee,0);
  END IF;

  IF NEW.transport = 'Yes' THEN
    total := total + COALESCE(fs.transport_fee,0);
  END IF;

  -- Payments already made in same academic year/term (if any)
  SELECT COALESCE(SUM(amount), 0) INTO paid_so_far
  FROM public.fee_transactions 
  WHERE student_id = NEW.id 
    AND academic_year = fs.academic_year 
    AND academic_term = fs.academic_term 
    AND status = 'completed';

  -- Upsert student_fees
  INSERT INTO public.student_fees (
    student_id, fee_structure_id, academic_year, academic_term,
    total_assigned_fees, total_paid, balance, payment_status, created_at, updated_at
  ) VALUES (
    NEW.id, fs.id, fs.academic_year, fs.academic_term,
    total, paid_so_far, GREATEST(total - paid_so_far, 0),
    CASE 
      WHEN paid_so_far >= total THEN 'Paid'
      WHEN paid_so_far > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END,
    NOW(), NOW()
  )
  ON CONFLICT (student_id, academic_year, academic_term) DO UPDATE
  SET fee_structure_id = EXCLUDED.fee_structure_id,
      total_assigned_fees = EXCLUDED.total_assigned_fees,
      balance = EXCLUDED.total_assigned_fees - student_fees.total_paid,
      payment_status = CASE 
        WHEN student_fees.total_paid >= EXCLUDED.total_assigned_fees THEN 'Paid'
        WHEN student_fees.total_paid > 0 THEN 'Partial'
        ELSE 'Unpaid'
      END,
      updated_at = NOW();

  RETURN NEW;
END;
$func$;

-- 3) Trigger on students to auto-assign/update fees when relevant fields change
DROP TRIGGER IF EXISTS trg_auto_assign_student_fees ON public.students;
CREATE TRIGGER trg_auto_assign_student_fees
AFTER INSERT OR UPDATE OF class, boarding_status, transport ON public.students
FOR EACH ROW EXECUTE FUNCTION public.auto_assign_student_fees_v2();

-- 4) Keep student_fees totals in sync when payments change
-- Insert/Update
DROP TRIGGER IF EXISTS trg_update_student_fees_on_payment ON public.fee_transactions;
CREATE TRIGGER trg_update_student_fees_on_payment
AFTER INSERT OR UPDATE ON public.fee_transactions
FOR EACH ROW EXECUTE FUNCTION public.update_student_fees_on_payment();

-- Delete (recalculate)
CREATE OR REPLACE FUNCTION public.update_student_fees_after_delete()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  UPDATE student_fees 
  SET 
    total_paid = (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_fee_id = OLD.student_fee_id 
      AND status = 'completed'
    ),
    payment_status = CASE 
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_fee_id = OLD.student_fee_id 
        AND status = 'completed'
      ) >= total_assigned_fees THEN 'Paid'
      WHEN (
        SELECT COALESCE(SUM(amount), 0) 
        FROM fee_transactions 
        WHERE student_fee_id = OLD.student_fee_id 
        AND status = 'completed'
      ) > 0 THEN 'Partial'
      ELSE 'Unpaid'
    END,
    balance = total_assigned_fees - (
      SELECT COALESCE(SUM(amount), 0) 
      FROM fee_transactions 
      WHERE student_fee_id = OLD.student_fee_id 
      AND status = 'completed'
    ),
    updated_at = NOW()
  WHERE id = OLD.student_fee_id;

  RETURN OLD;
END;
$function$;

DROP TRIGGER IF EXISTS trg_update_student_fees_after_delete ON public.fee_transactions;
CREATE TRIGGER trg_update_student_fees_after_delete
AFTER DELETE ON public.fee_transactions
FOR EACH ROW EXECUTE FUNCTION public.update_student_fees_after_delete();

-- 5) Backfill: trigger fee assignment for all existing students (fires the trigger above)
UPDATE public.students SET class = class;

-- 6) Minimal messaging schema (MVP)
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL DEFAULT 'announcement',              -- 'announcement' | 'direct'
  channel TEXT NOT NULL DEFAULT 'in_app',                 -- 'in_app' | 'email' | 'sms' | 'whatsapp'
  title TEXT,
  body TEXT NOT NULL,
  sender_name TEXT,
  created_by TEXT,
  status TEXT NOT NULL DEFAULT 'draft',                   -- 'draft' | 'queued' | 'sent' | 'failed'
  scheduled_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Allow all operations on messages"
  ON public.messages FOR ALL
  USING (true) WITH CHECK (true);

CREATE TABLE IF NOT EXISTS public.message_targets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id UUID NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL,                              -- 'all' | 'class' | 'teacher' | 'student'
  target_id UUID,                                         -- class_streams.id / teachers.id / students.id (nullable for 'all')
  recipient_contact TEXT,                                 -- optional email/phone for direct delivery
  status TEXT NOT NULL DEFAULT 'pending',                 -- 'pending' | 'sent' | 'failed'
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.message_targets ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS "Allow all operations on message_targets"
  ON public.message_targets FOR ALL
  USING (true) WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_messages_status ON public.messages(status);
CREATE INDEX IF NOT EXISTS idx_message_targets_message_id ON public.message_targets(message_id);
CREATE INDEX IF NOT EXISTS idx_message_targets_target ON public.message_targets(target_type, target_id);
