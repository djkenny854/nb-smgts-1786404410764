package app.nativeforge.smgts;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
