
import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';

const SearchLoadingSkeleton = () => {
  return (
    <div className="space-y-3 p-4">
      <div className="text-sm text-muted-foreground mb-3">Searching...</div>
      {[...Array(5)].map((_, index) => (
        <div key={index} className="flex items-center space-x-3 p-2 rounded-lg border">
          <Skeleton className="h-10 w-10 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
          <Skeleton className="h-6 w-16 rounded-full" />
        </div>
      ))}
    </div>
  );
};

export default SearchLoadingSkeleton;
