
import React from 'react';
import { useToast } from '@/components/ui/use-toast';
import { Loader, CheckCircle2, AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface DataSyncIndicatorProps {
  status: 'syncing' | 'success' | 'error' | 'idle' | 'online' | 'offline';
  message?: string;
}

const DataSyncIndicator = ({ status, message = '' }: DataSyncIndicatorProps) => {
  const { toast } = useToast();
  
  React.useEffect(() => {
    if (status === 'error') {
      toast({
        title: "Sync Failed",
        description: message || "There was a problem syncing your data. Please try again.",
        variant: "destructive"
      });
    } else if (status === 'success') {
      toast({
        title: "Sync Complete",
        description: message || "Your data has been successfully synced.",
        duration: 3000,
      });
    } else if (status === 'offline') {
      toast({
        title: "Working Offline",
        description: "You're currently working offline. Changes will sync when you reconnect.",
        duration: 5000,
      });
    }
  }, [status, message, toast]);
  
  if (status === 'idle') return null;
  
  const getStatusDisplay = () => {
    switch (status) {
      case 'syncing':
        return { 
          icon: <Loader className="h-3 w-3 animate-spin" />,
          text: 'Syncing data...',
          variant: 'outline'
        };
      case 'success':
        return { 
          icon: <CheckCircle2 className="h-3 w-3" />,
          text: 'Data synced',
          variant: 'success'
        };
      case 'error':
        return { 
          icon: <AlertCircle className="h-3 w-3" />,
          text: 'Sync failed',
          variant: 'destructive'
        };
      case 'online':
        return { 
          icon: <Wifi className="h-3 w-3" />,
          text: 'Connected',
          variant: 'outline'
        };
      case 'offline':
        return { 
          icon: <WifiOff className="h-3 w-3" />,
          text: 'Offline',
          variant: 'destructive'
        };
      default:
        return { 
          icon: null,
          text: '',
          variant: 'outline'
        };
    }
  };
  
  const { icon, text, variant } = getStatusDisplay();
  
  return (
    <Badge 
      variant={variant as any}
      className="fixed bottom-4 right-4 z-50 flex items-center gap-2 px-3 py-2"
    >
      {icon}
      {message || text}
    </Badge>
  );
};

export default DataSyncIndicator;
