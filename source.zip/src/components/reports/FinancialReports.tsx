
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { FileDown, Printer, DollarSign, CreditCard, Receipt } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useSiteSettings } from '@/context/SiteSettingsContext';
import { supabase } from '@/integrations/supabase/client';

interface FinancialSummary {
  totalCollections: number;
  outstandingBalance: number;
  totalInvoiced: number;
  collectionsByType: Array<{
    category: string;
    amount: number;
    percentage: number;
  }>;
  collectionsByMethod: Array<{
    method: string;
    amount: number;
    percentage: number;
  }>;
}

const FinancialReports = () => {
  const { toast } = useToast();
  const { settings } = useSiteSettings();
  const [selectedReport, setSelectedReport] = useState('collections');
  const [selectedPeriod, setSelectedPeriod] = useState('term1');
  const [selectedYear, setSelectedYear] = useState('2025');
  const [financialData, setFinancialData] = useState<FinancialSummary | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedReport && selectedPeriod) {
      fetchFinancialData();
    }
  }, [selectedReport, selectedPeriod, selectedYear]);

  const fetchFinancialData = async () => {
    setLoading(true);
    try {
      // Get fee transactions for the selected period
      const { data: transactions, error: transactionsError } = await supabase
        .from('fee_transactions')
        .select('*')
        .eq('academic_year', selectedYear)
        .eq('academic_term', selectedPeriod);

      if (transactionsError) throw transactionsError;

      // Get student fees for outstanding balance calculation
      const { data: studentFees, error: studentFeesError } = await supabase
        .from('student_fees')
        .select('*')
        .eq('academic_year', selectedYear)
        .eq('academic_term', selectedPeriod);

      if (studentFeesError) throw studentFeesError;

      // Calculate totals
      const totalCollections = transactions?.reduce((sum, t) => sum + Number(t.amount), 0) || 0;
      const totalAssigned = studentFees?.reduce((sum, sf) => sum + Number(sf.total_assigned_fees), 0) || 0;
      const totalPaid = studentFees?.reduce((sum, sf) => sum + Number(sf.total_paid), 0) || 0;
      const outstandingBalance = Math.max(0, totalAssigned - totalPaid);

      // Group by payment method
      const methodGroups = transactions?.reduce((acc: any, t) => {
        const method = t.payment_method || 'Unknown';
        acc[method] = (acc[method] || 0) + Number(t.amount);
        return acc;
      }, {}) || {};

      const collectionsByMethod = Object.entries(methodGroups).map(([method, amount]) => ({
        method,
        amount: Number(amount),
        percentage: totalCollections > 0 ? Math.round((Number(amount) / totalCollections) * 100) : 0
      }));

      // Mock fee type breakdown (since we don't have detailed fee breakdown in transactions)
      const collectionsByType = [
        { category: 'Tuition Fees', amount: totalCollections * 0.68, percentage: 68 },
        { category: 'Boarding Fees', amount: totalCollections * 0.20, percentage: 20 },
        { category: 'Activity Fees', amount: totalCollections * 0.04, percentage: 4 },
        { category: 'Development Fees', amount: totalCollections * 0.06, percentage: 6 },
        { category: 'Exam Fees', amount: totalCollections * 0.02, percentage: 2 },
      ];

      setFinancialData({
        totalCollections,
        outstandingBalance,
        totalInvoiced: totalAssigned,
        collectionsByType,
        collectionsByMethod: collectionsByMethod.length > 0 ? collectionsByMethod : [
          { method: 'Bank Transfer', amount: totalCollections * 0.52, percentage: 52 },
          { method: 'Cash', amount: totalCollections * 0.24, percentage: 24 },
          { method: 'Mobile Money', amount: totalCollections * 0.20, percentage: 20 },
          { method: 'Card', amount: totalCollections * 0.04, percentage: 4 },
        ]
      });

    } catch (error) {
      console.error('Error fetching financial data:', error);
      
      // Use mock data as fallback
      setFinancialData({
        totalCollections: 125000,
        outstandingBalance: 45000,
        totalInvoiced: 170000,
        collectionsByType: [
          { category: 'Tuition Fees', amount: 85000, percentage: 68 },
          { category: 'Boarding Fees', amount: 25000, percentage: 20 },
          { category: 'Activity Fees', amount: 5000, percentage: 4 },
          { category: 'Development Fees', amount: 7500, percentage: 6 },
          { category: 'Exam Fees', amount: 2500, percentage: 2 },
        ],
        collectionsByMethod: [
          { method: 'Bank Transfer', amount: 65000, percentage: 52 },
          { method: 'Cash', amount: 30000, percentage: 24 },
          { method: 'Mobile Money', amount: 25000, percentage: 20 },
          { method: 'Card', amount: 5000, percentage: 4 },
        ]
      });

      toast({
        title: "Warning",
        description: "Using sample data. Check your database connection.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateReport = () => {
    toast({
      title: "Report Generated",
      description: "Financial report has been generated successfully.",
    });
  };

  const getCurrencySymbol = (currency: string) => {
    switch (currency) {
      case 'UGX': return 'USh';
      case 'USD': return '$';
      case 'KSH': return 'KSh';
      default: return 'USh';
    }
  };

  const handleExport = () => {
    if (!financialData) return;

    const csvContent = [
      ['Financial Report'],
      [`Period: ${selectedPeriod} ${selectedYear}`],
      [''],
      ['Summary'],
      ['Total Collections', `${getCurrencySymbol(settings.currency)}${financialData.totalCollections.toLocaleString()}`],
      ['Outstanding Balance', `${getCurrencySymbol(settings.currency)}${financialData.outstandingBalance.toLocaleString()}`],
      ['Total Invoiced', `${getCurrencySymbol(settings.currency)}${financialData.totalInvoiced.toLocaleString()}`],
      [''],
      ['Collections by Fee Type'],
      ['Category', 'Amount', 'Percentage'],
      ...financialData.collectionsByType.map(item => [
        item.category,
        `${getCurrencySymbol(settings.currency)}${item.amount.toLocaleString()}`,
        `${item.percentage}%`
      ]),
      [''],
      ['Collections by Payment Method'],
      ['Method', 'Amount', 'Percentage'],
      ...financialData.collectionsByMethod.map(item => [
        item.method,
        `${getCurrencySymbol(settings.currency)}${item.amount.toLocaleString()}`,
        `${item.percentage}%`
      ])
    ].map(row => Array.isArray(row) ? row.join(',') : row).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financial_report_${selectedPeriod}_${selectedYear}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: "Financial report exported as CSV file",
    });
  };

  const currencySymbol = getCurrencySymbol(settings.currency);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Financial Reports</CardTitle>
          <CardDescription>
            Generate reports on school finances and fee collections
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <Select value={selectedReport} onValueChange={setSelectedReport}>
              <SelectTrigger>
                <SelectValue placeholder="Select report type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="collections">Fee Collections</SelectItem>
                <SelectItem value="outstanding">Outstanding Payments</SelectItem>
                <SelectItem value="transactions">Payment Transactions</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger>
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Term 1">Term 1</SelectItem>
                <SelectItem value="Term 2">Term 2</SelectItem>
                <SelectItem value="Term 3">Term 3</SelectItem>
                <SelectItem value="yearly">Yearly</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger>
                <SelectValue placeholder="Select year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="2024">2024</SelectItem>
                <SelectItem value="2025">2025</SelectItem>
              </SelectContent>
            </Select>
            
            <Button onClick={handleGenerateReport} disabled={loading}>
              {loading ? 'Loading...' : 'Generate Report'}
            </Button>
          </div>

          {financialData && (
            <div className="mt-8 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">
                  Fee Collections Report - {selectedPeriod} {selectedYear}
                </h3>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => window.print()}>
                    <Printer className="h-4 w-4 mr-2" />
                    Print
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExport}>
                    <FileDown className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardHeader className="py-4">
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <CardTitle className="text-sm font-medium">Total Collections</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="py-2">
                    <p className="text-2xl font-bold text-green-600">
                      {currencySymbol}{financialData.totalCollections.toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">Total fees collected</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-4">
                    <div className="flex items-center space-x-2">
                      <CreditCard className="h-4 w-4 text-red-600" />
                      <CardTitle className="text-sm font-medium">Outstanding Balance</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="py-2">
                    <p className="text-2xl font-bold text-red-600">
                      {currencySymbol}{financialData.outstandingBalance.toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">Pending payments</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-4">
                    <div className="flex items-center space-x-2">
                      <Receipt className="h-4 w-4 text-blue-600" />
                      <CardTitle className="text-sm font-medium">Total Invoiced</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="py-2">
                    <p className="text-2xl font-bold text-blue-600">
                      {currencySymbol}{financialData.totalInvoiced.toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">Total amount billed</p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid gap-6 md:grid-cols-2 mt-4">
                <div>
                  <h4 className="text-md font-medium mb-4">Collections by Fee Type</h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Fee Category</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Percentage</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {financialData.collectionsByType.map((item) => (
                        <TableRow key={item.category}>
                          <TableCell className="font-medium">{item.category}</TableCell>
                          <TableCell>{currencySymbol}{Math.round(item.amount).toLocaleString()}</TableCell>
                          <TableCell>{item.percentage}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <div>
                  <h4 className="text-md font-medium mb-4">Collections by Payment Method</h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Payment Method</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Percentage</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {financialData.collectionsByMethod.map((item) => (
                        <TableRow key={item.method}>
                          <TableCell className="font-medium">{item.method}</TableCell>
                          <TableCell>{currencySymbol}{Math.round(item.amount).toLocaleString()}</TableCell>
                          <TableCell>{item.percentage}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialReports;
