
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageSquare, Send, Clock, AlertTriangle, TrendingUp, Users } from 'lucide-react';
import { MessagingService } from '@/utils/messagingService';
import { Message, MessageTemplate, ContactGroup } from '@/types/messaging';
import MessageCenter from './MessageCenter';

const MessagingDashboard = () => {
  const [showFullCenter, setShowFullCenter] = useState(false);
  const [stats, setStats] = useState({
    totalMessages: 0,
    sentToday: 0,
    pendingMessages: 0,
    failedMessages: 0,
    activeTemplates: 0,
    contactGroups: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const [messages, templates, groups] = await Promise.all([
        MessagingService.fetchMessages(),
        MessagingService.fetchTemplates(),
        MessagingService.fetchContactGroups(),
      ]);

      const today = new Date().toDateString();
      const sentToday = messages.filter(m => 
        m.sent_at && new Date(m.sent_at).toDateString() === today
      ).length;

      setStats({
        totalMessages: messages.length,
        sentToday,
        pendingMessages: messages.filter(m => m.status === 'pending').length,
        failedMessages: messages.filter(m => m.status === 'failed').length,
        activeTemplates: templates.length,
        contactGroups: groups.length,
      });
    } catch (error) {
      console.error('Error loading messaging stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (showFullCenter) {
    return <MessageCenter />;
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Messaging</h2>
          <p className="text-muted-foreground">
            Communication hub for school notifications and announcements.
          </p>
        </div>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Messaging</h2>
          <p className="text-muted-foreground">
            Communication hub for SMS, Email, and WhatsApp messaging.
          </p>
        </div>
        <Button onClick={() => setShowFullCenter(true)} size="lg">
          <MessageSquare className="h-4 w-4 mr-2" />
          Open Message Center
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalMessages}</div>
            <p className="text-xs text-muted-foreground">
              All time messages sent
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sent Today</CardTitle>
            <Send className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.sentToday}</div>
            <p className="text-xs text-muted-foreground">
              Messages delivered today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingMessages}</div>
            <p className="text-xs text-muted-foreground">
              Queued for delivery
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.failedMessages}</div>
            <p className="text-xs text-muted-foreground">
              Delivery failed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Templates</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeTemplates}</div>
            <p className="text-xs text-muted-foreground">
              Available templates
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Contact Groups</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.contactGroups}</div>
            <p className="text-xs text-muted-foreground">
              Configured groups
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button onClick={() => setShowFullCenter(true)} className="h-20 flex-col">
              <Send className="h-6 w-6 mb-2" />
              Compose Message
            </Button>
            <Button onClick={() => setShowFullCenter(true)} variant="outline" className="h-20 flex-col">
              <MessageSquare className="h-6 w-6 mb-2" />
              Manage Templates
            </Button>
            <Button onClick={() => setShowFullCenter(true)} variant="outline" className="h-20 flex-col">
              <Users className="h-6 w-6 mb-2" />
              Contact Groups
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Features Available</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold">Multi-Channel Messaging</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• SMS messaging via Twilio</li>
                <li>• Email campaigns via SendGrid</li>
                <li>• WhatsApp Business messaging</li>
                <li>• Message scheduling and automation</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Smart Features</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Template-based messaging</li>
                <li>• Dynamic contact groups</li>
                <li>• Delivery tracking and analytics</li>
                <li>• Automated fee reminders</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MessagingDashboard;
