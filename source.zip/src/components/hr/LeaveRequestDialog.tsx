
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { Tables } from '@/integrations/supabase/types';
import { supabase } from '@/integrations/supabase/client';

type StaffLeaveRequest = Tables<'staff_leave_requests'>;
type Teacher = Tables<'teachers'>;

interface LeaveRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  request?: StaffLeaveRequest | null;
  teachers: Teacher[];
  onSuccess: () => void;
}

const LeaveRequestDialog: React.FC<LeaveRequestDialogProps> = ({
  open,
  onOpenChange,
  request,
  teachers,
  onSuccess
}) => {
  const [formData, setFormData] = useState({
    teacher_id: '',
    leave_type: 'annual',
    start_date: '',
    end_date: '',
    days_requested: '',
    reason: '',
  });
  const [loading, setLoading] = useState(false);
  const [date, setDate] = useState<Date | undefined>(undefined);
  const { toast } = useToast();

  useEffect(() => {
    if (request) {
      setFormData({
        teacher_id: request.teacher_id || '',
        leave_type: request.leave_type || 'annual',
        start_date: request.start_date || '',
        end_date: request.end_date || '',
        days_requested: request.days_requested?.toString() || '',
        reason: request.reason || '',
      });
    } else {
      setFormData({
        teacher_id: teachers?.[0]?.id || '',
        leave_type: 'annual',
        start_date: '',
        end_date: '',
        days_requested: '',
        reason: '',
      });
    }
  }, [request, open, teachers]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = {
        teacher_id: formData.teacher_id,
        leave_type: formData.leave_type as StaffLeaveRequest['leave_type'],
        start_date: formData.start_date,
        end_date: formData.end_date,
        days_requested: parseInt(formData.days_requested) || 0,
        reason: formData.reason,
      };

      if (request) {
        const { error } = await supabase
          .from('staff_leave_requests')
          .update(data)
          .eq('id', request.id);
        
        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Leave request updated successfully"
        });
      } else {
        const { error } = await supabase
          .from('staff_leave_requests')
          .insert([data]);

        if (error) throw error;
        
        toast({
          title: "Success",
          description: "Leave request submitted successfully"
        });
      }
      
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error saving leave request:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to save leave request",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{request ? 'Edit Leave Request' : 'Submit Leave Request'}</DialogTitle>
          <DialogDescription>
            {request ? 'Update the leave request details below.' : 'Fill in the details for the new leave request.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="teacher_id">Teacher *</Label>
              <Select value={formData.teacher_id} onValueChange={(value) => setFormData({ ...formData, teacher_id: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {teachers.map((teacher) => (
                    <SelectItem key={teacher.id} value={teacher.id}>{teacher.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="leave_type">Leave Type *</Label>
              <Select value={formData.leave_type} onValueChange={(value) => setFormData({ ...formData, leave_type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual</SelectItem>
                  <SelectItem value="sick">Sick</SelectItem>
                  <SelectItem value="maternity">Maternity</SelectItem>
                  <SelectItem value="paternity">Paternity</SelectItem>
                  <SelectItem value="emergency">Emergency</SelectItem>
                  <SelectItem value="study">Study</SelectItem>
                  <SelectItem value="unpaid">Unpaid</SelectItem>
                  <SelectItem value="compassionate">Compassionate</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Start Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-[240px] justify-start text-left font-normal",
                      !formData.start_date && "text-muted-foreground"
                    )}
                  >
                    {formData.start_date ? (
                      format(new Date(formData.start_date), "PPP")
                    ) : (
                      <span>Pick a date</span>
                    )}
                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    defaultMonth={new Date()}
                    selected={date}
                    onSelect={(date) => {
                      setDate(date)
                      setFormData({ ...formData, start_date: date?.toISOString().split('T')[0] || '' })
                    }}
                    disabled={(date) =>
                      date > new Date()
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>End Date *</Label>
              <Input
                type="date"
                value={formData.end_date}
                onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="days_requested">Days Requested *</Label>
            <Input
              id="days_requested"
              type="number"
              value={formData.days_requested}
              onChange={(e) => setFormData({ ...formData, days_requested: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason *</Label>
            <Textarea
              id="reason"
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              rows={3}
              placeholder="Reason for leave..."
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Saving...' : request ? 'Update Request' : 'Submit Request'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default LeaveRequestDialog;
