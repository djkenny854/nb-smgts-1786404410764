import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import TimetableCell from './TimetableCell';
import TimetableSkeleton from './TimetableSkeleton';
import LiveLessonsIndicator from './LiveLessonsIndicator';

interface Subject {
  id: string;
  name: string;
  code: string;
}

interface Teacher {
  id: string;
  name: string;
}

interface TimetableEntry {
  id: string;
  class_name: string;
  day_of_week: number;
  period_number: number;
  subject_id: string | null;
  teacher_id: string | null;
  start_time: string;
  end_time: string;
  room?: string;
  subjects: Subject | null;
  teachers: Teacher | null;
}

interface WeeklyTimetableProps {
  selectedClass: string;
  onTimetableChange?: () => void;
}

const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const periods = [1, 2, 3, 4, 5, 6, 7, 8];

const WeeklyTimetable: React.FC<WeeklyTimetableProps> = ({ selectedClass, onTimetableChange }) => {
  const [timetableData, setTimetableData] = useState<TimetableEntry[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [liveLessons, setLiveLessons] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchTimetableData();
    fetchSubjects();
    fetchTeachers();
    setupRealtimeSubscription();
  }, [selectedClass]);

  useEffect(() => {
    updateLiveLessons();
    const interval = setInterval(updateLiveLessons, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, [timetableData]);

  const updateLiveLessons = () => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0=Sunday, 1=Monday, etc.
    const currentTime = now.toTimeString().slice(0, 5);

    const currentLiveLessons = new Set<string>();
    
    timetableData.forEach(entry => {
      if (
        entry.day_of_week === dayOfWeek &&
        entry.start_time <= currentTime &&
        entry.end_time > currentTime
      ) {
        currentLiveLessons.add(`${entry.day_of_week}-${entry.period_number}`);
      }
    });

    setLiveLessons(currentLiveLessons);
    
    // Update the global window object for dashboard access
    if (typeof window !== 'undefined') {
      (window as any).currentLiveLessons = Array.from(currentLiveLessons);
      (window as any).timetableLiveData = timetableData.filter(entry => 
        entry.day_of_week === dayOfWeek &&
        entry.start_time <= currentTime &&
        entry.end_time > currentTime
      );
    }
  };

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel('timetable_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'timetable',
          filter: `class_name=eq.${selectedClass}`
        },
        () => {
          fetchTimetableData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const fetchTimetableData = async () => {
    if (!selectedClass) return;

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('timetable')
        .select(`
          *,
          subjects(id, name, code),
          teachers(id, name)
        `)
        .eq('class_name', selectedClass);

      if (error) throw error;
      
      const typedData: TimetableEntry[] = (data || []).map(entry => ({
        ...entry,
        subjects: entry.subjects ? {
          id: entry.subjects.id,
          name: entry.subjects.name,
          code: entry.subjects.code
        } : null,
        teachers: entry.teachers ? {
          id: entry.teachers.id,
          name: entry.teachers.name
        } : null
      }));
      
      setTimetableData(typedData);
      if (onTimetableChange) {
        onTimetableChange();
      }
    } catch (error) {
      console.error('Error fetching timetable data:', error);
      toast.error('Failed to load timetable data');
    } finally {
      setLoading(false);
    }
  };

  const fetchSubjects = async () => {
    try {
      const { data, error } = await supabase
        .from('subjects')
        .select('id, name, code');

      if (error) throw error;
      setSubjects(data as Subject[]);
    } catch (error) {
      console.error('Error fetching subjects:', error);
      toast.error('Failed to load subjects');
    }
  };

  const fetchTeachers = async () => {
    try {
      const { data, error } = await supabase
        .from('teachers')
        .select('id, name');

      if (error) throw error;
      setTeachers(data as Teacher[]);
    } catch (error) {
      console.error('Error fetching teachers:', error);
      toast.error('Failed to load teachers');
    }
  };

  const handleSubjectChange = async (dayIndex: number, period: number, subjectId: string | null) => {
    try {
      const existingEntry = timetableData.find(
        entry => entry.day_of_week === dayIndex && entry.period_number === period
      );

      if (existingEntry) {
        const { error } = await supabase
          .from('timetable')
          .update({ subject_id: subjectId, updated_at: new Date().toISOString() })
          .eq('id', existingEntry.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('timetable')
          .insert({
            class_name: selectedClass,
            day_of_week: dayIndex,
            period_number: period,
            subject_id: subjectId,
            start_time: '08:00',
            end_time: '09:00'
          });

        if (error) throw error;
      }

      await fetchTimetableData();
      toast.success('Subject updated successfully');
    } catch (error) {
      console.error('Error updating subject:', error);
      toast.error('Failed to update subject');
    }
  };

  const handleTeacherChange = async (dayIndex: number, period: number, teacherId: string | null) => {
    try {
      const existingEntry = timetableData.find(
        entry => entry.day_of_week === dayIndex && entry.period_number === period
      );

      if (existingEntry) {
        const { error } = await supabase
          .from('timetable')
          .update({ teacher_id: teacherId, updated_at: new Date().toISOString() })
          .eq('id', existingEntry.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('timetable')
          .insert({
            class_name: selectedClass,
            day_of_week: dayIndex,
            period_number: period,
            teacher_id: teacherId,
            start_time: '08:00',
            end_time: '09:00'
          });

        if (error) throw error;
      }

      await fetchTimetableData();
      toast.success('Teacher updated successfully');
    } catch (error) {
      console.error('Error updating teacher:', error);
      toast.error('Failed to update teacher');
    }
  };

  const handleTimeEdit = async (dayIndex: number, period: number, startTime: string, endTime: string) => {
    try {
      const existingEntry = timetableData.find(
        entry => entry.day_of_week === dayIndex && entry.period_number === period
      );

      if (existingEntry) {
        const { error } = await supabase
          .from('timetable')
          .update({
            start_time: startTime,
            end_time: endTime,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingEntry.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('timetable')
          .insert({
            class_name: selectedClass,
            day_of_week: dayIndex,
            period_number: period,
            start_time: startTime,
            end_time: endTime
          });

        if (error) throw error;
      }

      await fetchTimetableData();
      toast.success('Time updated successfully');
    } catch (error) {
      console.error('Error updating time:', error);
      toast.error('Failed to update time');
    }
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Weekly Timetable - {selectedClass}</CardTitle>
          <LiveLessonsIndicator />
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        {loading ? (
          <TimetableSkeleton />
        ) : (
          <div className="grid grid-cols-8 gap-2 min-w-[1200px] group">
            <div></div>
            {daysOfWeek.map((day, dayIndex) => {
              const today = new Date().getDay();
              const isToday = dayIndex === today;
              return (
                <div key={dayIndex} className={`font-semibold text-center p-2 rounded-lg transition-colors ${
                  isToday ? 'bg-primary text-primary-foreground' : 'bg-muted'
                }`}>
                  {day}
                  {isToday && <div className="text-xs mt-1">Today</div>}
                </div>
              );
            })}
            {periods.map((period) => (
              <React.Fragment key={period}>
                <div className="font-semibold text-center p-2 bg-muted rounded-lg flex items-center justify-center">
                  Period {period}
                </div>
                {daysOfWeek.map((day, dayIndex) => {
                  const entry = timetableData.find(
                    e => e.day_of_week === dayIndex && e.period_number === period
                  );
                  const isLive = liveLessons.has(`${dayIndex}-${period}`);

                  return (
                    <TimetableCell
                      key={dayIndex}
                      entry={entry || null}
                      dayIndex={dayIndex}
                      period={period}
                      subjects={subjects}
                      teachers={teachers}
                      onSubjectChange={handleSubjectChange}
                      onTeacherChange={handleTeacherChange}
                      onTimeEdit={handleTimeEdit}
                      isLive={isLive}
                    />
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default WeeklyTimetable;
