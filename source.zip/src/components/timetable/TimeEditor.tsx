
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';

interface TimeEditorProps {
  startTime: string;
  endTime: string;
  onSave: (startTime: string, endTime: string) => void;
  onCancel: () => void;
}

const TimeEditor: React.FC<TimeEditorProps> = ({ startTime, endTime, onSave, onCancel }) => {
  const [newStartTime, setNewStartTime] = useState(startTime);
  const [newEndTime, setNewEndTime] = useState(endTime);

  const handleSave = () => {
    if (newStartTime && newEndTime && newStartTime < newEndTime) {
      onSave(newStartTime, newEndTime);
    }
  };

  return (
    <div className="flex flex-col gap-2 p-2 bg-primary/10 rounded border border-primary/20 shadow-sm">
      <div className="flex gap-1 items-center">
        <Input
          type="time"
          value={newStartTime}
          onChange={(e) => setNewStartTime(e.target.value)}
          className="text-xs h-6 flex-1"
          placeholder="Start"
        />
        <span className="text-xs text-muted-foreground">-</span>
        <Input
          type="time"
          value={newEndTime}
          onChange={(e) => setNewEndTime(e.target.value)}
          className="text-xs h-6 flex-1"
          placeholder="End"
        />
      </div>
      <div className="flex gap-1 justify-center">
        <Button 
          size="sm" 
          variant="default" 
          onClick={handleSave}
          className="h-6 px-2"
          disabled={!newStartTime || !newEndTime || newStartTime >= newEndTime}
        >
          <Check className="h-3 w-3" />
        </Button>
        <Button 
          size="sm" 
          variant="outline" 
          onClick={onCancel}
          className="h-6 px-2"
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
};

export default TimeEditor;
