
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit2, Plus, Bus, Car } from 'lucide-react';

const TransportVehicles = () => {
  const vehicles = [
    { id: 'v1', name: 'Bus 01', type: 'bus', capacity: 42, registrationNo: 'KL-01-AB-1234', lastMaintenance: '2023-03-15', status: 'operational' },
    { id: 'v2', name: 'Bus 02', type: 'bus', capacity: 42, registrationNo: 'KL-01-AB-5678', lastMaintenance: '2023-02-20', status: 'operational' },
    { id: 'v3', name: 'Bus 03', type: 'bus', capacity: 42, registrationNo: 'KL-01-AB-9012', lastMaintenance: '2023-04-05', status: 'maintenance' },
    { id: 'v4', name: 'Van 01', type: 'van', capacity: 12, registrationNo: 'KL-01-CD-3456', lastMaintenance: '2023-03-25', status: 'operational' },
    { id: 'v5', name: 'Van 02', type: 'van', capacity: 12, registrationNo: 'KL-01-CD-7890', lastMaintenance: '2023-01-10', status: 'operational' },
  ];

  const getVehicleIcon = (type: string) => {
    switch (type) {
      case 'bus':
        return <Bus className="h-4 w-4 mr-2 text-muted-foreground" />;
      case 'van':
        return <Car className="h-4 w-4 mr-2 text-muted-foreground" />;
      default:
        return <Car className="h-4 w-4 mr-2 text-muted-foreground" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Fleet Management</h2>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Add Vehicle
        </Button>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Vehicle</TableHead>
                <TableHead>Capacity</TableHead>
                <TableHead>Registration No.</TableHead>
                <TableHead>Last Maintenance</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vehicles.map((vehicle) => (
                <TableRow key={vehicle.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      {getVehicleIcon(vehicle.type)}
                      {vehicle.name}
                    </div>
                  </TableCell>
                  <TableCell>{vehicle.capacity} seats</TableCell>
                  <TableCell>{vehicle.registrationNo}</TableCell>
                  <TableCell>{vehicle.lastMaintenance}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={vehicle.status === 'operational' ? 'success' : 'outline'}
                    >
                      {vehicle.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon">
                      <Edit2 className="h-4 w-4" />
                      <span className="sr-only">Edit</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default TransportVehicles;
