
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { CalendarIcon, Save, Users, AlertTriangle, Clock } from 'lucide-react';
import { format, isFuture, isToday } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Student {
  id: string;
  full_name: string;
  student_id: string;
  class: string;
}

interface ClassStream {
  id: string;
  full_name: string;
  class_level: string;
  stream_name: string;
}

interface PendingClass {
  class_name: string;
  total_students: number;
  marked_students: number;
  pending_students: number;
}

export const AttendanceMarker = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [students, setStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<ClassStream[]>([]);
  const [pendingClasses, setPendingClasses] = useState<PendingClass[]>([]);
  const [attendance, setAttendance] = useState<Record<string, 'present' | 'absent' | 'late' | 'excused'>>({});
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [attendanceSettings, setAttendanceSettings] = useState({
    allowFutureAttendance: false,
    lockAfterHours: 24,
    defaultTypes: ['present', 'absent', 'late', 'excused']
  });
  const { toast } = useToast();

  useEffect(() => {
    fetchClasses();
    fetchPendingAttendance();
    loadAttendanceSettings();
  }, []);

  useEffect(() => {
    if (selectedClass) {
      fetchStudents();
      fetchExistingAttendance();
    }
  }, [selectedClass, selectedDate]);

  useEffect(() => {
    if (isToday(selectedDate)) {
      fetchPendingAttendance();
    }
  }, [selectedDate]);

  const loadAttendanceSettings = () => {
    // Load from localStorage or API
    const savedSettings = localStorage.getItem('attendanceSettings');
    if (savedSettings) {
      setAttendanceSettings(JSON.parse(savedSettings));
    }
  };

  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('class_streams')
        .select('*')
        .order('class_level');

      if (error) throw error;
      setClasses(data || []);
    } catch (error) {
      console.error('Error fetching classes:', error);
      toast({
        title: "Error",
        description: "Failed to fetch classes",
        variant: "destructive"
      });
    }
  };

  const fetchPendingAttendance = async () => {
    if (!isToday(selectedDate)) return;

    try {
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      
      // Get all classes with student counts
      const { data: classData, error: classError } = await supabase
        .from('available_classes')
        .select('*');

      if (classError) throw classError;

      // Get attendance records for today
      const { data: attendanceData, error: attendanceError } = await supabase
        .from('attendance')
        .select('student_id, students!inner(class)')
        .eq('date', dateStr);

      if (attendanceError) throw attendanceError;

      // Calculate pending for each class
      const pending: PendingClass[] = [];
      
      for (const classItem of classData || []) {
        const markedInClass = attendanceData?.filter(
          a => a.students.class === classItem.class_name
        ).length || 0;
        
        const totalStudents = classItem.student_count || 0;
        const pendingStudents = Math.max(0, totalStudents - markedInClass);

        if (pendingStudents > 0) {
          pending.push({
            class_name: classItem.class_name,
            total_students: totalStudents,
            marked_students: markedInClass,
            pending_students: pendingStudents
          });
        }
      }

      setPendingClasses(pending);
    } catch (error) {
      console.error('Error fetching pending attendance:', error);
    }
  };

  const fetchStudents = async () => {
    if (!selectedClass) return;
    
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('class', selectedClass)
        .order('full_name');

      if (error) throw error;
      setStudents(data || []);
      
      // Initialize attendance state
      const initialAttendance: Record<string, 'present' | 'absent' | 'late' | 'excused'> = {};
      (data || []).forEach((student) => {
        initialAttendance[student.id] = 'absent';
      });
      setAttendance(initialAttendance);
    } catch (error) {
      console.error('Error fetching students:', error);
      toast({
        title: "Error",
        description: "Failed to fetch students",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchExistingAttendance = async () => {
    if (!selectedClass || !selectedDate) return;

    try {
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      const { data, error } = await supabase
        .from('attendance')
        .select('student_id, status')
        .eq('date', dateStr);

      if (error) throw error;

      const existingAttendance: Record<string, 'present' | 'absent' | 'late' | 'excused'> = {};
      data?.forEach((record) => {
        existingAttendance[record.student_id] = record.status as 'present' | 'absent' | 'late' | 'excused';
      });
      
      setAttendance(prev => ({ ...prev, ...existingAttendance }));
    } catch (error) {
      console.error('Error fetching existing attendance:', error);
    }
  };

  const toggleAttendance = (studentId: string) => {
    const currentStatus = attendance[studentId];
    const statuses: ('present' | 'absent' | 'late' | 'excused')[] = ['present', 'absent', 'late', 'excused'];
    const currentIndex = statuses.indexOf(currentStatus);
    const nextIndex = (currentIndex + 1) % statuses.length;
    
    setAttendance(prev => ({
      ...prev,
      [studentId]: statuses[nextIndex]
    }));
  };

  const markAllStatus = (status: 'present' | 'absent' | 'late' | 'excused') => {
    const newAttendance: Record<string, 'present' | 'absent' | 'late' | 'excused'> = {};
    students.forEach((student) => {
      newAttendance[student.id] = status;
    });
    setAttendance(newAttendance);
  };

  const saveAttendance = async () => {
    if (!selectedClass || !selectedDate) return;

    // Prevent future attendance if not allowed
    if (isFuture(selectedDate) && !attendanceSettings.allowFutureAttendance) {
      toast({
        title: "Cannot Take Future Attendance",
        description: "Attendance cannot be taken for future dates according to your settings.",
        variant: "destructive"
      });
      return;
    }

    try {
      setSaving(true);
      const dateStr = format(selectedDate, 'yyyy-MM-dd');

      // Delete existing attendance for this date and class
      const studentsInClass = students.map(s => s.id);
      await supabase
        .from('attendance')
        .delete()
        .eq('date', dateStr)
        .in('student_id', studentsInClass);

      // Insert new attendance records
      const attendanceRecords = Object.entries(attendance).map(([studentId, status]) => ({
        date: dateStr,
        student_id: studentId,
        status: status,
        created_by: 'system',
        updated_by: 'system'
      }));

      const { error } = await supabase
        .from('attendance')
        .insert(attendanceRecords);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Attendance saved for ${selectedClass} on ${format(selectedDate, 'PPP')}`,
      });

      // Refresh pending attendance if it's today
      if (isToday(selectedDate)) {
        fetchPendingAttendance();
      }
    } catch (error) {
      console.error('Error saving attendance:', error);
      toast({
        title: "Error",
        description: "Failed to save attendance",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present': return 'bg-green-500 text-white';
      case 'absent': return 'bg-red-500 text-white';
      case 'late': return 'bg-yellow-500 text-white';
      case 'excused': return 'bg-blue-500 text-white';
      default: return 'bg-gray-500 text-white';
    }
  };

  const getStatusCounts = () => {
    const counts = { present: 0, absent: 0, late: 0, excused: 0 };
    Object.values(attendance).forEach(status => {
      counts[status]++;
    });
    return counts;
  };

  const statusCounts = getStatusCounts();

  return (
    <div className="space-y-6">
      {/* Pending Attendance Alert */}
      {isToday(new Date()) && pendingClasses.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-orange-800">
              <AlertTriangle className="h-5 w-5" />
              Pending Attendance Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {pendingClasses.map((pendingClass) => (
                <div key={pendingClass.class_name} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div>
                    <p className="font-medium text-gray-900">{pendingClass.class_name}</p>
                    <p className="text-sm text-gray-600">
                      {pendingClass.marked_students}/{pendingClass.total_students} marked
                    </p>
                  </div>
                  <Badge variant="outline" className="bg-orange-100 text-orange-700">
                    {pendingClass.pending_students} pending
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Attendance Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Take Attendance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Class</label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((classStream) => (
                    <SelectItem key={classStream.id} value={classStream.full_name}>
                      {classStream.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Select Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground",
                      isFuture(selectedDate) && !attendanceSettings.allowFutureAttendance && "border-red-300 bg-red-50"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : <span>Pick a date</span>}
                    {isFuture(selectedDate) && !attendanceSettings.allowFutureAttendance && (
                      <Clock className="ml-2 h-4 w-4 text-red-500" />
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                    disabled={(date) => 
                      isFuture(date) && !attendanceSettings.allowFutureAttendance
                    }
                  />
                </PopoverContent>
              </Popover>
              {isFuture(selectedDate) && !attendanceSettings.allowFutureAttendance && (
                <p className="text-sm text-red-600">Future attendance is disabled in settings</p>
              )}
            </div>
          </div>

          {selectedClass && (
            <div className="flex items-center justify-between">
              <div className="flex gap-2">
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  Present: {statusCounts.present}
                </Badge>
                <Badge variant="outline" className="bg-red-50 text-red-700">
                  Absent: {statusCounts.absent}
                </Badge>
                <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                  Late: {statusCounts.late}
                </Badge>
                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                  Excused: {statusCounts.excused}
                </Badge>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => markAllStatus('present')}>
                  All Present
                </Button>
                <Button size="sm" variant="outline" onClick={() => markAllStatus('absent')}>
                  All Absent
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Students Grid */}
      {selectedClass && (
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedClass} - {format(selectedDate, "PPP")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent mx-auto mb-2"></div>
                  <p className="text-sm text-muted-foreground">Loading students...</p>
                </div>
              </div>
            ) : students.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No students found</h3>
                <p className="text-gray-500">No students are enrolled in this class.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
                  {students.map((student) => (
                    <div
                      key={student.id}
                      className="p-3 border-2 rounded-lg cursor-pointer transition-all hover:shadow-md"
                      onClick={() => toggleAttendance(student.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{student.full_name}</p>
                          <p className="text-sm text-gray-600">ID: {student.student_id}</p>
                        </div>
                        <Badge className={getStatusColor(attendance[student.id])}>
                          {attendance[student.id]}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-end">
                  <Button 
                    onClick={saveAttendance} 
                    disabled={saving || (isFuture(selectedDate) && !attendanceSettings.allowFutureAttendance)}
                    className="min-w-[120px]"
                  >
                    {saving ? (
                      <>
                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent mr-2"></div>
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Attendance
                      </>
                    )}
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};
