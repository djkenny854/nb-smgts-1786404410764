
import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DollarSign, Plus, History, RefreshCw, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import PaymentModal from '@/components/fees/PaymentModal';
import FeeAssignmentModal from '@/components/fees/FeeAssignmentModal';

interface StudentFeeBalanceProps {
  studentId: string;
}

const StudentFeeBalance: React.FC<StudentFeeBalanceProps> = ({ studentId }) => {
  const [selectedFeeRecord, setSelectedFeeRecord] = useState(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isFeeAssignmentModalOpen, setIsFeeAssignmentModalOpen] = useState(false);
  const [student, setStudent] = useState(null);
  const { toast } = useToast();

  // Fetch student data
  useEffect(() => {
    const fetchStudent = async () => {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();
      
      if (error) {
        console.error('Error fetching student:', error);
      } else {
        setStudent(data);
      }
    };

    fetchStudent();
  }, [studentId]);

  // Query for student fees with improved error handling
  const { data: studentFees, isLoading: feesLoading, refetch: refetchFees, error: feesError } = useQuery({
    queryKey: ['student-fees', studentId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('student_fees')
        .select(`
          *,
          fee_structures(
            name,
            academic_year,
            academic_term
          )
        `)
        .eq('student_id', studentId)
        .order('academic_year', { ascending: false })
        .order('academic_term', { ascending: false });

      if (error) {
        console.error('Error fetching student fees:', error);
        throw error;
      }
      
      console.log('Student fees:', data);
      return data || [];
    },
    refetchInterval: 10000, // Refetch every 10 seconds to catch updates
    retry: 3, // Retry up to 3 times on failure
  });

  // Query for recent transactions with improved error handling
  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ['fee-transactions', studentId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fee_transactions')
        .select('*')
        .eq('student_id', studentId)
        .order('payment_date', { ascending: false })
        .limit(10);

      if (error) {
        console.error('Error fetching transactions:', error);
        throw error;
      }
      return data || [];
    },
    retry: 2,
  });

  const handleAddPayment = (feeRecord) => {
    const studentFeeRecord = {
      ...feeRecord,
      students: student
    };
    setSelectedFeeRecord(studentFeeRecord);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentSuccess = () => {
    refetchFees();
    setIsPaymentModalOpen(false);
    setSelectedFeeRecord(null);
    toast({
      title: "Success",
      description: "Payment recorded successfully"
    });
  };

  const handleAssignFees = () => {
    setIsFeeAssignmentModalOpen(true);
  };

  const handleFeeAssignmentSuccess = () => {
    refetchFees();
    setIsFeeAssignmentModalOpen(false);
    toast({
      title: "Success",
      description: "Fee structure assigned successfully"
    });
  };

  const getPaymentStatusColor = (status) => {
    switch (status) {
      case 'Paid':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Partial':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Unpaid':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPaymentProgress = (totalPaid, totalAssigned) => {
    if (totalAssigned === 0) return 0;
    return Math.min((totalPaid / totalAssigned) * 100, 100);
  };

  if (feesError) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            Error Loading Fee Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-red-600 mb-4">
            Unable to load fee information. Please try refreshing the page.
          </p>
          <Button onClick={() => refetchFees()} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (feesLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Fee Balance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Fee Balance Overview */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5" />
            Fee Balance Overview
          </CardTitle>
          <Button
            onClick={() => refetchFees()}
            variant="outline"
            size="sm"
            className="flex items-center gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {!studentFees || studentFees.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 mb-4">No fee records found for this student.</p>
              <Button onClick={handleAssignFees} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Assign Fee Structure
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {studentFees.map((feeRecord) => {
                const balance = Math.max(0, (feeRecord.total_assigned_fees || 0) - (feeRecord.total_paid || 0));
                const progress = getPaymentProgress(feeRecord.total_paid || 0, feeRecord.total_assigned_fees || 0);
                
                return (
                  <div key={feeRecord.id} className="border rounded-lg p-6 bg-white shadow-sm">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-semibold text-lg">
                          {feeRecord.academic_year} - {feeRecord.academic_term}
                        </h3>
                        <Badge className={getPaymentStatusColor(feeRecord.payment_status)}>
                          {feeRecord.payment_status}
                        </Badge>
                        {feeRecord.fee_structures && (
                          <p className="text-sm text-gray-600 mt-1">
                            Structure: {feeRecord.fee_structures.name}
                          </p>
                        )}
                      </div>
                      <Button
                        onClick={() => handleAddPayment(feeRecord)}
                        size="sm"
                        className="flex items-center gap-2"
                        disabled={balance <= 0}
                      >
                        <Plus className="h-4 w-4" />
                        Add Payment
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Total Fees</p>
                        <p className="text-2xl font-semibold">
                          UGX {(feeRecord.total_assigned_fees || 0).toLocaleString()}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Amount Paid</p>
                        <p className="text-2xl font-semibold text-green-600">
                          UGX {(feeRecord.total_paid || 0).toLocaleString()}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-600">Balance</p>
                        <p className="text-2xl font-semibold text-red-600">
                          UGX {balance.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Progress bar */}
                    <div className="space-y-2">
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div
                          className="bg-blue-600 h-3 rounded-full transition-all duration-500"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                      <p className="text-sm text-gray-600 text-center">
                        Payment Progress: {Math.round(progress)}%
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5" />
            Recent Transactions
          </CardTitle>
        </CardHeader>
        <CardContent>
          {transactionsLoading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : !transactions || transactions.length === 0 ? (
            <p className="text-gray-500 text-center py-8">No transactions found</p>
          ) : (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div key={transaction.id} className="flex justify-between items-center p-4 border rounded-lg bg-white">
                  <div>
                    <p className="font-medium">UGX {(transaction.amount || 0).toLocaleString()}</p>
                    <p className="text-sm text-gray-600">
                      {new Date(transaction.payment_date).toLocaleDateString()} - {transaction.payment_method}
                    </p>
                    {transaction.receipt_number && (
                      <p className="text-xs text-gray-500">Receipt: {transaction.receipt_number}</p>
                    )}
                  </div>
                  <Badge variant="outline">{transaction.status || 'Completed'}</Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modals */}
      {selectedFeeRecord && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          studentFee={selectedFeeRecord}
          onSuccess={handlePaymentSuccess}
        />
      )}

      {student && (
        <FeeAssignmentModal
          isOpen={isFeeAssignmentModalOpen}
          onClose={() => setIsFeeAssignmentModalOpen(false)}
          student={student}
          onSuccess={handleFeeAssignmentSuccess}
        />
      )}
    </div>
  );
};

export default StudentFeeBalance;
