
import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { StudentFormValues } from './form-sections/StudentFormSchema';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import GenderAvatar from '@/components/common/GenderAvatar';

interface StudentConfirmationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  studentData: StudentFormValues;
  onConfirm: () => void;
  profileImageUrl?: string;
}

const StudentConfirmationDialog: React.FC<StudentConfirmationDialogProps> = ({
  open,
  onOpenChange,
  studentData,
  onConfirm,
  profileImageUrl
}) => {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-2xl">
        <AlertDialogHeader>
          <AlertDialogTitle>Confirm Student Registration</AlertDialogTitle>
          <AlertDialogDescription>
            Please review the student information before submitting.
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="space-y-4 py-4">
          {/* Student Preview */}
          <div className="flex items-center gap-4 p-4 bg-muted/20 rounded-lg">
            {profileImageUrl ? (
              <Avatar className="w-16 h-16">
                <AvatarImage src={profileImageUrl} alt={studentData.name} />
                <AvatarFallback>
                  <GenderAvatar gender={studentData.gender} size="md" />
                </AvatarFallback>
              </Avatar>
            ) : (
              <GenderAvatar gender={studentData.gender} size="md" />
            )}
            <div>
              <h3 className="font-semibold text-lg">{studentData.name}</h3>
              <p className="text-muted-foreground">ID: {studentData.enrollmentNumber}</p>
              <p className="text-sm text-muted-foreground">Class: {studentData.className}</p>
            </div>
          </div>

          {/* Key Information */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Gender:</span> {studentData.gender || 'Not specified'}
            </div>
            <div>
              <span className="font-medium">Date of Birth:</span> {studentData.dateOfBirth || 'Not specified'}
            </div>
            <div>
              <span className="font-medium">Parent:</span> {studentData.parentName || 'Not specified'}
            </div>
            <div>
              <span className="font-medium">Contact:</span> {studentData.parentContact || 'Not specified'}
            </div>
            <div>
              <span className="font-medium">Boarding:</span> {studentData.boardingStatus}
            </div>
            <div>
              <span className="font-medium">Transport:</span> {studentData.transportUse}
            </div>
          </div>

          {/* Special Notes */}
          {(studentData.medicalConditions || studentData.bloodGroup) && (
            <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <h4 className="font-medium text-yellow-800 mb-2">Medical Information</h4>
              {studentData.bloodGroup && (
                <p className="text-sm text-yellow-700">Blood Group: {studentData.bloodGroup}</p>
              )}
              {studentData.medicalConditions && (
                <p className="text-sm text-yellow-700">Conditions: {studentData.medicalConditions}</p>
              )}
            </div>
          )}
        </div>

        <AlertDialogFooter>
          <AlertDialogCancel>Review Again</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm} className="bg-primary hover:bg-primary/90">
            Confirm & Register Student
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};

export default StudentConfirmationDialog;
