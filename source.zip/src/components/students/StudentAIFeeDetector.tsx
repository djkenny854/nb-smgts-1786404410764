
import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, DollarSign, Calculator, Info } from 'lucide-react';
import { useSiteSettings } from '@/context/SiteSettingsContext';

interface StudentAIFeeDetectorProps {
  selectedClass?: string;
  boardingStatus?: string;
  transportUse?: string;
  onFeesCalculated?: (fees: FeeBreakdown) => void;
}

interface FeeBreakdown {
  tuition: number;
  boarding: number;
  transport: number;
  activities: number;
  total: number;
}

const StudentAIFeeDetector: React.FC<StudentAIFeeDetectorProps> = ({
  selectedClass,
  boardingStatus,
  transportUse,
  onFeesCalculated
}) => {
  const { settings } = useSiteSettings();
  const [isCalculating, setIsCalculating] = useState(false);
  const [feeBreakdown, setFeeBreakdown] = useState<FeeBreakdown | null>(null);
  const [aiInsight, setAiInsight] = useState<string>('');

  useEffect(() => {
    if (selectedClass) {
      calculateFees();
    }
  }, [selectedClass, boardingStatus, transportUse]);

  const calculateFees = async () => {
    setIsCalculating(true);
    
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Base fee structure (these could come from your fee settings)
    const baseFees = {
      tuition: 500000, // UGX 500,000
      boarding: boardingStatus === 'Boarding' ? 300000 : 0,
      transport: transportUse === 'Yes' ? 50000 : 0,
      activities: 25000, // Standard activities fee
    };

    // Class-specific adjustments (AI logic simulation)
    let multiplier = 1;
    let classInsight = '';

    if (selectedClass) {
      const classLevel = parseInt(selectedClass.replace(/\D/g, '')) || 1;
      
      if (classLevel >= 10) {
        multiplier = 1.2;
        classInsight = 'Senior classes have additional laboratory and practical fees.';
      } else if (classLevel >= 7) {
        multiplier = 1.1;
        classInsight = 'Middle school includes enhanced learning materials and activities.';
      } else {
        classInsight = 'Primary level with standard curriculum and basic activities.';
      }
    }

    const calculatedFees: FeeBreakdown = {
      tuition: Math.round(baseFees.tuition * multiplier),
      boarding: baseFees.boarding,
      transport: baseFees.transport,
      activities: baseFees.activities,
      total: 0
    };

    calculatedFees.total = calculatedFees.tuition + calculatedFees.boarding + calculatedFees.transport + calculatedFees.activities;

    // Generate AI insight
    let insight = `Based on ${selectedClass || 'the selected class'}, ${classInsight}`;
    
    if (boardingStatus === 'Boarding') {
      insight += ' Boarding fees include accommodation, meals, and supervision.';
    }
    
    if (transportUse === 'Yes') {
      insight += ' Transport fee covers daily pickup and drop-off services.';
    }

    setFeeBreakdown(calculatedFees);
    setAiInsight(insight);
    setIsCalculating(false);

    // Notify parent component
    if (onFeesCalculated) {
      onFeesCalculated(calculatedFees);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: settings.currency || 'UGX',
      minimumFractionDigits: 0
    }).format(amount);
  };

  if (!selectedClass) {
    return (
      <Card className="border-dashed border-muted-foreground/25">
        <CardContent className="flex items-center justify-center py-6">
          <div className="text-center text-muted-foreground">
            <Brain className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Select a class to see AI fee calculation</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-blue-200 bg-blue-50/50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-blue-900">
          <Brain className="h-5 w-5" />
          AI Fee Calculator
          {isCalculating && (
            <Badge variant="secondary" className="animate-pulse">
              Calculating...
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isCalculating ? (
          <div className="flex items-center justify-center py-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calculator className="h-4 w-4 animate-spin" />
              <span className="text-sm">Analyzing fee structure...</span>
            </div>
          </div>
        ) : feeBreakdown ? (
          <>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Tuition Fee:</span>
                <span className="font-medium">{formatCurrency(feeBreakdown.tuition)}</span>
              </div>
              
              {feeBreakdown.boarding > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Boarding Fee:</span>
                  <span className="font-medium">{formatCurrency(feeBreakdown.boarding)}</span>
                </div>
              )}
              
              {feeBreakdown.transport > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Transport Fee:</span>
                  <span className="font-medium">{formatCurrency(feeBreakdown.transport)}</span>
                </div>
              )}
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Activities Fee:</span>
                <span className="font-medium">{formatCurrency(feeBreakdown.activities)}</span>
              </div>
              
              <hr className="my-2" />
              
              <div className="flex justify-between items-center font-bold text-lg">
                <span className="flex items-center gap-1">
                  <DollarSign className="h-4 w-4" />
                  Total Fee:
                </span>
                <span className="text-green-600">{formatCurrency(feeBreakdown.total)}</span>
              </div>
            </div>

            {aiInsight && (
              <div className="bg-blue-100 rounded-lg p-3 border-l-4 border-blue-500">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-blue-800">{aiInsight}</p>
                </div>
              </div>
            )}
          </>
        ) : null}
      </CardContent>
    </Card>
  );
};

export default StudentAIFeeDetector;
