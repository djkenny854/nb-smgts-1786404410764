
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Search, Plus, Users, Filter } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import StudentCard from './StudentCard';
import StudentDetailView from './StudentDetailView';
import { Preloader } from '@/components/ui/preloader';

const StudentList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [isDetailView, setIsDetailView] = useState(false);

  const { data: students, isLoading, error, refetch } = useQuery({
    queryKey: ['students', searchTerm, classFilter, statusFilter],
    queryFn: async () => {
      let query = supabase
        .from('students')
        .select(`
          *,
          student_fees(
            total_assigned_fees,
            total_paid,
            balance,
            payment_status
          )
        `)
        .order('full_name');

      if (searchTerm) {
        query = query.or(`full_name.ilike.%${searchTerm}%,student_id.ilike.%${searchTerm}%`);
      }

      if (classFilter !== 'all') {
        query = query.eq('class', classFilter);
      }

      if (statusFilter !== 'all') {
        query = query.eq('fee_status', statusFilter);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    }
  });

  const { data: classes } = useQuery({
    queryKey: ['unique-classes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('students')
        .select('class')
        .order('class');

      if (error) throw error;
      
      const uniqueClasses = [...new Set(data?.map(item => item.class) || [])];
      return uniqueClasses;
    }
  });

  const handleViewDetails = (student: any) => {
    setSelectedStudent(student);
    setIsDetailView(true);
  };

  const handleBackToList = () => {
    setIsDetailView(false);
    setSelectedStudent(null);
    refetch();
  };

  const getStatusCounts = () => {
    if (!students) return { total: 0, paid: 0, partial: 0, unpaid: 0 };
    
    return {
      total: students.length,
      paid: students.filter(s => s.fee_status === 'Paid').length,
      partial: students.filter(s => s.fee_status === 'Partial').length,
      unpaid: students.filter(s => s.fee_status === 'Unpaid').length,
    };
  };

  const statusCounts = getStatusCounts();

  if (isDetailView && selectedStudent) {
    return (
      <StudentDetailView
        student={selectedStudent}
        onEdit={() => {
          // TODO: Implement edit functionality
          console.log('Edit student:', selectedStudent);
        }}
        onBack={handleBackToList}
      />
    );
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Preloader size="lg" text="Loading students..." />
      </div>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-red-600">
            <p>Error loading students: {error.message}</p>
            <Button onClick={() => refetch()} variant="outline" className="mt-2">
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Students ({statusCounts.total})
              </CardTitle>
              <div className="flex gap-4 mt-2">
                <Badge className="bg-green-100 text-green-800">
                  Paid: {statusCounts.paid}
                </Badge>
                <Badge className="bg-blue-100 text-blue-800">
                  Partial: {statusCounts.partial}
                </Badge>
                <Badge className="bg-red-100 text-red-800">
                  Unpaid: {statusCounts.unpaid}
                </Badge>
              </div>
            </div>
            <Button className="flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Student
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by name or student ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={classFilter} onValueChange={setClassFilter}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classes?.map((className) => (
                  <SelectItem key={className} value={className}>
                    {className}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by fee status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Paid">Paid</SelectItem>
                <SelectItem value="Partial">Partial</SelectItem>
                <SelectItem value="Unpaid">Unpaid</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {students?.map((student) => (
          <StudentCard
            key={student.id}
            student={student}
            onViewDetails={handleViewDetails}
          />
        ))}
      </div>

      {students?.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No students found</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || classFilter !== 'all' || statusFilter !== 'all'
                ? 'Try adjusting your search criteria'
                : 'Get started by adding your first student'
              }
            </p>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Student
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default StudentList;
