
import React from 'react';
import { Control } from 'react-hook-form';
import {
  FormField,
  FormItem,
  FormControl,
  FormMessage,
} from '@/components/ui/form';
import { GoogleInput } from '@/components/ui/google-input';
import { GoogleSelect, GoogleSelectItem } from '@/components/ui/google-select';
import { StudentFormValues } from './StudentFormSchema';

export interface BasicInfoSectionProps {
  control: Control<StudentFormValues>;
}

const BasicInfoSection: React.FC<BasicInfoSectionProps> = ({ control }) => {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        👤 Basic Information
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={control}
          name="name"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleInput
                  label="Full Name *"
                  {...field}
                  error={fieldState.error?.message}
                  helperText="Enter student's complete name"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="gender"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleSelect
                  label="Gender"
                  value={field.value}
                  onValueChange={field.onChange}
                  error={fieldState.error?.message}
                  helperText="Select student's gender"
                >
                  <GoogleSelectItem value="Male">Male</GoogleSelectItem>
                  <GoogleSelectItem value="Female">Female</GoogleSelectItem>
                </GoogleSelect>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="dateOfBirth"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleInput
                  label="Date of Birth"
                  type="date"
                  {...field}
                  error={fieldState.error?.message}
                  helperText="Student's birth date"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={control}
          name="email"
          render={({ field, fieldState }) => (
            <FormItem>
              <FormControl>
                <GoogleInput
                  label="Email Address"
                  type="email"
                  {...field}
                  error={fieldState.error?.message}
                  helperText="Student's email for communication"
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>

      <FormField
        control={control}
        name="address"
        render={({ field, fieldState }) => (
          <FormItem>
            <FormControl>
              <GoogleInput
                label="Home Address"
                {...field}
                error={fieldState.error?.message}
                helperText="Complete residential address"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
};

export default BasicInfoSection;
