import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, Users, AlertTriangle, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const StudentAIInsights = () => {
  const { data: insights, isLoading } = useQuery({
    queryKey: ['student-ai-insights'],
    queryFn: async () => {
      const { data: students, error } = await supabase
        .from('students')
        .select(`
          *,
          student_fees (
            total_assigned_fees,
            total_paid,
            balance,
            payment_status
          )
        `);

      if (error) throw error;

      const totalStudents = students?.length || 0;
      const boardingStudents = students?.filter(s => s.boarding_status === 'Boarding').length || 0;
      const transportStudents = students?.filter(s => s.transport === 'Yes').length || 0;
      
      const paidStudents = students?.filter(s => s.student_fees?.[0]?.payment_status === 'Paid').length || 0;
      const partialPaidStudents = students?.filter(s => s.student_fees?.[0]?.payment_status === 'Partial').length || 0;
      const unpaidStudents = students?.filter(s => s.student_fees?.[0]?.payment_status === 'Unpaid').length || 0;
      
      const totalOutstanding = students?.reduce((sum, s) => sum + (s.student_fees?.[0]?.balance || 0), 0) || 0;
      const totalCollected = students?.reduce((sum, s) => sum + (s.student_fees?.[0]?.total_paid || 0), 0) || 0;

      const classDistribution = students?.reduce((acc, student) => {
        const className = student.class || 'Unknown';
        acc[className] = (acc[className] || 0) + 1;
        return acc;
      }, {} as Record<string, number>) || {};

      const largestClass = Object.entries(classDistribution).sort((a, b) => b[1] - a[1])[0];
      const smallestClass = Object.entries(classDistribution).sort((a, b) => a[1] - b[1])[0];

      return {
        totalStudents,
        boardingStudents,
        transportStudents,
        paidStudents,
        partialPaidStudents,
        unpaidStudents,
        totalOutstanding,
        totalCollected,
        classDistribution,
        largestClass: largestClass ? { name: largestClass[0], count: largestClass[1] } : null,
        smallestClass: smallestClass ? { name: smallestClass[0], count: smallestClass[1] } : null,
        collectionRate: totalStudents > 0 ? (paidStudents / totalStudents) * 100 : 0,
        boardingRate: totalStudents > 0 ? (boardingStudents / totalStudents) * 100 : 0,
      };
    },
    refetchInterval: 30000,
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Student Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
            <div className="h-4 bg-muted rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          AI Student Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">{insights?.totalStudents}</div>
            <div className="text-sm text-muted-foreground">Total Students</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500">
              {insights?.collectionRate?.toFixed(1)}%
            </div>
            <div className="text-sm text-muted-foreground">Payment Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-500">
              {insights?.boardingRate?.toFixed(1)}%
            </div>
            <div className="text-sm text-muted-foreground">Boarding Students</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-500 truncate">
              UGX {(insights?.totalOutstanding || 0).toLocaleString()}
            </div>
            <div className="text-sm text-muted-foreground">Outstanding</div>
          </div>
        </div>

        {/* AI Insights */}
        <div className="space-y-3">
          <h4 className="font-semibold flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Smart Insights
          </h4>

          {insights && insights.unpaidStudents > 0 && (
            <div className="p-3 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4" />
                <span className="font-medium">Payment Alert</span>
              </div>
              <p className="text-sm mt-1">
                {insights.unpaidStudents} students haven't made any payments yet. 
                Consider sending fee reminders.
              </p>
            </div>
          )}

          {insights?.largestClass && insights?.smallestClass && (
            <div className="p-3 rounded-lg bg-primary/10 text-primary">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="font-medium">Class Distribution</span>
              </div>
              <p className="text-sm mt-1">
                Largest class: {insights.largestClass.name} ({insights.largestClass.count} students). 
                Smallest class: {insights.smallestClass.name} ({insights.smallestClass.count} students).
              </p>
            </div>
          )}

          {insights && insights.paidStudents > 0 && (
            <div className="p-3 rounded-lg bg-green-500/10 text-green-600 dark:text-green-400">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                <span className="font-medium">Collection Success</span>
              </div>
              <p className="text-sm mt-1">
                {insights.paidStudents} students have completed their fee payments. 
                UGX {insights.totalCollected.toLocaleString()} collected so far.
              </p>
            </div>
          )}
        </div>

        {/* Fee Status Distribution */}
        <div className="space-y-2">
          <h5 className="font-medium">Fee Payment Status</h5>
          <div className="flex gap-2 flex-wrap">
            <Badge variant="outline" className="bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20">
              Paid: {insights?.paidStudents}
            </Badge>
            <Badge variant="outline" className="bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20">
              Partial: {insights?.partialPaidStudents}
            </Badge>
            <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
              Unpaid: {insights?.unpaidStudents}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StudentAIInsights;
