
import React from 'react';
import { Student } from '@/types';
import StudentCard from './StudentCard';

interface StudentGridProps {
  students: Student[];
  onStudentClick: (student: Student) => void;
  loading: boolean;
}

const StudentGrid = ({ students, onStudentClick, loading }: StudentGridProps) => {
  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="bg-white rounded-lg border p-4">
              <div className="flex items-center space-x-4">
                <div className="rounded-full bg-gray-200 h-16 w-16"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-5 bg-gray-200 rounded w-1/3"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
                <div className="rounded-full bg-gray-200 h-16 w-16"></div>
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (students.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-lg border">
        <div className="text-gray-500 text-lg mb-2">No students found</div>
        <div className="text-gray-400 text-sm">Try adjusting your filters or add some students</div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {students.map((student) => {
        // Map the Student type to the expected StudentCard props
        const mappedStudent = {
          id: student.id,
          full_name: student.name,
          student_id: student.enrollmentNumber,
          class: student.className,
          boarding_status: student.boardingStatus,
          transport: student.transportUse,
          profile_image_url: student.profileImage
        };

        return (
          <StudentCard
            key={student.id}
            student={mappedStudent}
            onViewDetails={() => onStudentClick(student)}
          />
        );
      })}
    </div>
  );
};

export default StudentGrid;
