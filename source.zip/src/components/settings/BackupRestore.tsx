
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Database, Download, Upload, Clock, Shield, AlertTriangle, CheckCircle, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BackupRestore = () => {
  const [backupFrequency, setBackupFrequency] = useState('daily');
  const [autoBackup, setAutoBackup] = useState(true);
  const [backupLocation, setBackupLocation] = useState('cloud');
  const [retentionPeriod, setRetentionPeriod] = useState('30');
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const { toast } = useToast();

  const mockBackups = [
    { id: 1, name: 'Auto-backup-2024-01-26', date: '2024-01-26 02:00', size: '45.2 MB', status: 'completed' },
    { id: 2, name: 'Manual-backup-2024-01-25', date: '2024-01-25 14:30', size: '44.8 MB', status: 'completed' },
    { id: 3, name: 'Auto-backup-2024-01-25', date: '2024-01-25 02:00', size: '44.5 MB', status: 'completed' },
  ];

  const handleCreateBackup = () => {
    setIsBackingUp(true);
    setBackupProgress(0);
    
    // Simulate backup progress
    const interval = setInterval(() => {
      setBackupProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsBackingUp(false);
          toast({
            title: "Backup completed",
            description: "Database backup created successfully."
          });
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  const handleSaveSettings = () => {
    toast({
      title: "Settings saved",
      description: "Backup and restore settings have been updated."
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'failed':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Backup & Restore</h2>
        <p className="text-muted-foreground">Manage your data backups and restore options.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="mr-2 h-5 w-5" />
              Backup Settings
            </CardTitle>
            <CardDescription>Configure automatic backup preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Enable Auto Backup</Label>
                <p className="text-xs text-muted-foreground">
                  Automatically create backups on schedule
                </p>
              </div>
              <Switch checked={autoBackup} onCheckedChange={setAutoBackup} />
            </div>

            <div className="space-y-2">
              <Label>Backup Frequency</Label>
              <Select value={backupFrequency || 'daily'} onValueChange={setBackupFrequency}>
                <SelectTrigger>
                  <SelectValue placeholder="Select frequency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Hourly</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Backup Location</Label>
              <Select value={backupLocation || 'cloud'} onValueChange={setBackupLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cloud">Cloud Storage</SelectItem>
                  <SelectItem value="local">Local Storage</SelectItem>
                  <SelectItem value="both">Both</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Retention Period (Days)</Label>
              <Select value={retentionPeriod || '30'} onValueChange={setRetentionPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 Days</SelectItem>
                  <SelectItem value="14">14 Days</SelectItem>
                  <SelectItem value="30">30 Days</SelectItem>
                  <SelectItem value="60">60 Days</SelectItem>
                  <SelectItem value="90">90 Days</SelectItem>
                  <SelectItem value="365">1 Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="mr-2 h-5 w-5" />
              Manual Backup
            </CardTitle>
            <CardDescription>Create backup immediately</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Backup Name</Label>
                <Input placeholder="Enter backup name (optional)" />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Include Media Files</Label>
                  <p className="text-xs text-muted-foreground">
                    Include uploaded images and documents
                  </p>
                </div>
                <Switch defaultChecked />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>Compress Backup</Label>
                  <p className="text-xs text-muted-foreground">
                    Reduce file size with compression
                  </p>
                </div>
                <Switch defaultChecked />
              </div>

              {isBackingUp && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Creating backup...</span>
                    <span>{backupProgress}%</span>
                  </div>
                  <Progress value={backupProgress} className="w-full" />
                </div>
              )}

              <Button 
                onClick={handleCreateBackup} 
                disabled={isBackingUp}
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                {isBackingUp ? 'Creating Backup...' : 'Create Backup Now'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Recent Backups
            </CardTitle>
            <CardDescription>View and manage your backup history</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockBackups.map((backup) => (
                <div key={backup.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(backup.status)}
                    <div>
                      <p className="font-medium">{backup.name}</p>
                      <p className="text-sm text-muted-foreground">{backup.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-sm font-medium">{backup.size}</p>
                      <Badge className={getStatusColor(backup.status)}>
                        {backup.status}
                      </Badge>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                      <Button variant="outline" size="sm">
                        <Upload className="h-4 w-4 mr-1" />
                        Restore
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end pt-4">
        <Button onClick={handleSaveSettings} className="min-w-32">
          <Save className="h-4 w-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
};

export default BackupRestore;
