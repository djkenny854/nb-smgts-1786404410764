
import React, { useState } from 'react';
import { GraduationCap } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { CLASS_LEVELS } from '@/data/classLevels';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';

const ClassConfigCard = () => {
  const [classNaming, setClassNaming] = useState('standard');
  const [streamNaming, setStreamNaming] = useState('alphabet');
  const [autoGenerate, setAutoGenerate] = useState(true);
  const { toast } = useToast();

  const handleSaveConfig = () => {
    // In a real implementation, this would save to the database
    toast({
      title: "Settings saved",
      description: "Class configuration has been updated successfully."
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <GraduationCap className="mr-2 h-5 w-5" />
          Class Configuration
        </CardTitle>
        <CardDescription>Set up classes, streams and naming</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Class Naming Convention</label>
          <Select value={classNaming || "standard"} onValueChange={setClassNaming}>
            <SelectTrigger>
              <SelectValue placeholder="Select convention" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="standard">P1, P2, etc. with Baby, Middle, Top for Nursery</SelectItem>
              <SelectItem value="grade">Grade 1, Grade 2, etc.</SelectItem>
              <SelectItem value="year">Year 1, Year 2, etc.</SelectItem>
              <SelectItem value="form">Form 1, Form 2, etc.</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Stream Naming Convention</label>
          <Select value={streamNaming || "alphabet"} onValueChange={setStreamNaming}>
            <SelectTrigger>
              <SelectValue placeholder="Select convention" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="alphabet">A, B, C, etc.</SelectItem>
              <SelectItem value="color">Red, Blue, Green, etc.</SelectItem>
              <SelectItem value="number">1, 2, 3, etc.</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Auto-Generate Class Lists</label>
            <Switch checked={autoGenerate} onCheckedChange={setAutoGenerate} />
          </div>
          <p className="text-xs text-muted-foreground">
            When enabled, class lists will be auto-generated based on the naming conventions above
          </p>
        </div>

        <div className="space-y-2 pt-2">
          <h4 className="text-sm font-medium">Available Class Levels</h4>
          <div className="grid grid-cols-2 gap-2">
            {CLASS_LEVELS.map((level) => (
              <div key={level.id} className="border rounded p-2 text-sm">
                {level.displayName}
              </div>
            ))}
          </div>
        </div>
        
        <div className="pt-2">
          <Button onClick={handleSaveConfig}>Save Configuration</Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClassConfigCard;
