
import React from 'react';
import { Award } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';

interface GradingSystemCardProps {
  gradingSystem: string;
  setGradingSystem: (value: string) => void;
  passMark: string;
  setPassMark: (value: string) => void;
}

const GradingSystemCard = ({ 
  gradingSystem, 
  setGradingSystem, 
  passMark, 
  setPassMark 
}: GradingSystemCardProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Award className="mr-2 h-5 w-5" />
          Grading System
        </CardTitle>
        <CardDescription>Configure how student performances are graded</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Grading Type</label>
          <Select value={gradingSystem || "percentage"} onValueChange={setGradingSystem}>
            <SelectTrigger>
              <SelectValue placeholder="Select grading system" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="percentage">Percentage (0-100%)</SelectItem>
              <SelectItem value="letter">Letter Grade (A-F)</SelectItem>
              <SelectItem value="points">Points (1-12)</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium">Pass Mark</label>
          <Select value={passMark || "50"} onValueChange={setPassMark}>
            <SelectTrigger>
              <SelectValue placeholder="Select pass mark" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="40">40%</SelectItem>
              <SelectItem value="45">45%</SelectItem>
              <SelectItem value="50">50%</SelectItem>
              <SelectItem value="60">60%</SelectItem>
              <SelectItem value="70">70%</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {gradingSystem === 'letter' && (
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div>
              <label className="text-xs font-medium">A Grade</label>
              <div className="flex gap-2 items-center mt-1">
                <Input type="number" min="0" max="100" placeholder="80" className="w-20" />
                <span>% and above</span>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium">B Grade</label>
              <div className="flex gap-2 items-center mt-1">
                <Input type="number" min="0" max="100" placeholder="70" className="w-20" />
                <span>% and above</span>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium">C Grade</label>
              <div className="flex gap-2 items-center mt-1">
                <Input type="number" min="0" max="100" placeholder="60" className="w-20" />
                <span>% and above</span>
              </div>
            </div>
            <div>
              <label className="text-xs font-medium">D Grade</label>
              <div className="flex gap-2 items-center mt-1">
                <Input type="number" min="0" max="100" placeholder="50" className="w-20" />
                <span>% and above</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default GradingSystemCard;
