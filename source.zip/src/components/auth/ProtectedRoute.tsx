
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { toast } from "sonner";

type ProtectedRouteProps = {
  children: React.ReactNode;
};

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const location = useLocation();
  
  // DEVELOPMENT MODE: Always allow access - AUTHENTICATION DISABLED
  const devMode = true;

  // In development mode, always allow access
  if (devMode) {
    return <>{children}</>;
  }

  // Loading state (won't be reached in dev mode)
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="w-full max-w-md p-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-3 rounded-full bg-primary/10">
              <div className="h-8 w-8 rounded-full border-2 border-primary border-t-transparent animate-spin" />
            </div>
            <p className="text-sm text-muted-foreground">Loading ClassPilot...</p>
          </div>
        </div>
      </div>
    );
  }

  // Production mode: Check authentication (won't be reached in dev mode)
  if (!isAuthenticated) {
    toast.error("Please login to continue", {
      description: "You need to be logged in to access this page",
      duration: 4000,
    });
    
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
