
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Plus, Edit, Trash2, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface Exam {
  id: string;
  name: string;
  term: string;
  year: string;
  start_date: string;
  end_date: string;
  is_active: boolean;
  created_at: string;
}

const ExamSchedule = () => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    term: 'Term 1',
    year: new Date().getFullYear().toString(),
    start_date: '',
    end_date: '',
    is_active: false
  });

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('exams')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setExams(data || []);
    } catch (error) {
      console.error('Error fetching exams:', error);
      toast({
        title: "Error",
        description: "Failed to fetch exams",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!formData.name.trim()) {
        toast({
          title: "Error",
          description: "Exam name is required",
          variant: "destructive"
        });
        return;
      }

      if (!formData.start_date || !formData.end_date) {
        toast({
          title: "Error",
          description: "Start date and end date are required",
          variant: "destructive"
        });
        return;
      }

      if (new Date(formData.end_date) < new Date(formData.start_date)) {
        toast({
          title: "Error",
          description: "End date must be after start date",
          variant: "destructive"
        });
        return;
      }

      const examData = {
        id: editingId || crypto.randomUUID(),
        name: formData.name,
        term: formData.term,
        year: formData.year,
        start_date: formData.start_date,
        end_date: formData.end_date,
        is_active: formData.is_active,
        grade_scale: {
          "A": {"min": 80, "max": 100, "comment": "Excellent"},
          "B": {"min": 70, "max": 79, "comment": "Very Good"},
          "C": {"min": 60, "max": 69, "comment": "Good"},
          "D": {"min": 50, "max": 59, "comment": "Fair"},
          "F": {"min": 0, "max": 49, "comment": "Poor"}
        }
      };

      if (editingId) {
        const { error } = await supabase
          .from('exams')
          .update(examData)
          .eq('id', editingId);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('exams')
          .insert([examData]);

        if (error) throw error;
      }

      toast({
        title: "Success",
        description: editingId ? "Exam updated successfully" : "Exam created successfully"
      });

      resetForm();
      fetchExams();
    } catch (error) {
      console.error('Error saving exam:', error);
      toast({
        title: "Error",
        description: `Failed to save exam: ${error.message || 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };

  const handleEdit = (exam: Exam) => {
    setFormData({
      name: exam.name,
      term: exam.term,
      year: exam.year,
      start_date: exam.start_date.split('T')[0],
      end_date: exam.end_date.split('T')[0],
      is_active: exam.is_active
    });
    setEditingId(exam.id);
    setIsCreating(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this exam? This will also delete all associated results.')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('exams')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Exam deleted successfully"
      });
      fetchExams();
    } catch (error) {
      console.error('Error deleting exam:', error);
      toast({
        title: "Error",
        description: "Failed to delete exam",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      term: 'Term 1',
      year: new Date().getFullYear().toString(),
      start_date: '',
      end_date: '',
      is_active: false
    });
    setIsCreating(false);
    setEditingId(null);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusColor = (isActive: boolean) => {
    return isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return <div className="flex justify-center py-8">Loading exams...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Exam Schedule</h2>
          <p className="text-gray-600 mt-1">Create and manage examination schedules</p>
        </div>
        <Button 
          onClick={() => setIsCreating(true)} 
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Create Exam
        </Button>
      </div>

      {isCreating && (
        <Card>
          <CardHeader>
            <CardTitle>{editingId ? 'Edit Exam' : 'Create New Exam'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Exam Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="e.g., Mid Term Examination"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="term">Academic Term *</Label>
                  <Select 
                    value={formData.term} 
                    onValueChange={(value) => setFormData({...formData, term: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Term 1">Term 1</SelectItem>
                      <SelectItem value="Term 2">Term 2</SelectItem>
                      <SelectItem value="Term 3">Term 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="year">Academic Year *</Label>
                  <Input
                    id="year"
                    value={formData.year}
                    onChange={(e) => setFormData({...formData, year: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="start_date">Start Date *</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="end_date">End Date *</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
                  className="rounded"
                />
                <Label htmlFor="is_active">Set as Active Exam</Label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit">
                  {editingId ? 'Update Exam' : 'Create Exam'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {exams.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center">
              <Calendar className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500">No exams created yet</p>
              <p className="text-sm text-gray-400 mt-2">Create your first exam to get started</p>
            </CardContent>
          </Card>
        ) : (
          exams.map((exam) => (
            <Card key={exam.id}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{exam.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(exam.is_active)}`}>
                        {exam.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        <span>{exam.term}, {exam.year}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>{formatDate(exam.start_date)} - {formatDate(exam.end_date)}</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        Created: {formatDate(exam.created_at)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleEdit(exam)}
                      variant="outline"
                      size="sm"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      onClick={() => handleDelete(exam.id)}
                      variant="outline"
                      size="sm"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default ExamSchedule;
