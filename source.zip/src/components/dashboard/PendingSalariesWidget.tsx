import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { DollarSign, AlertTriangle, User, Calendar } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PendingSalariesWidget = () => {
  const navigate = useNavigate();
  
  const { data: salaryStats } = useQuery({
    queryKey: ['pending-salaries-stats'],
    queryFn: async () => {
      const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM
      const monthName = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      
      // Get all active teachers
      const { data: teachers } = await supabase
        .from('teachers')
        .select('id, name, salary')
        .eq('status', 'active');
      
      // Get teachers who have been paid this month
      const { data: paidSalaries } = await supabase
        .from('teacher_salaries')
        .select('teacher_id, amount')
        .like('month', `${currentMonth}%`);
      
      const totalTeachers = teachers?.length || 0;
      const paidTeachers = paidSalaries?.length || 0;
      const pendingTeachers = totalTeachers - paidTeachers;
      
      // Get unpaid teachers list
      const paidTeacherIds = paidSalaries?.map(s => s.teacher_id) || [];
      const unpaidTeachers = teachers?.filter(t => !paidTeacherIds.includes(t.id)) || [];
      
      // Calculate total pending amount
      const totalPendingAmount = unpaidTeachers.reduce((sum, teacher) => 
        sum + (Number(teacher.salary) || 0), 0
      );
      
      // Calculate total paid amount
      const totalPaidAmount = paidSalaries?.reduce((sum, salary) => 
        sum + Number(salary.amount), 0
      ) || 0;
      
      return {
        totalTeachers,
        paidTeachers,
        pendingTeachers,
        unpaidTeachers: unpaidTeachers.slice(0, 5), // Show first 5
        totalPendingAmount,
        totalPaidAmount,
        monthName
      };
    },
    refetchInterval: 60000, // Refresh every minute
  });

  if (!salaryStats) return null;

  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-green-500" />
          Salary Status
        </CardTitle>
        <Badge variant={salaryStats.pendingTeachers > 0 ? "destructive" : "default"}>
          {salaryStats.pendingTeachers} Pending
        </Badge>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          {salaryStats.monthName}
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-green-500/10 dark:bg-green-500/20 rounded-lg">
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">
              {salaryStats.paidTeachers}
            </div>
            <p className="text-xs text-muted-foreground">Teachers Paid</p>
          </div>
          <div className="text-center p-3 bg-destructive/10 dark:bg-destructive/20 rounded-lg">
            <div className="text-2xl font-bold text-destructive">
              {salaryStats.pendingTeachers}
            </div>
            <p className="text-xs text-muted-foreground">Pending Payment</p>
          </div>
        </div>
        
        {/* Pending Amount */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium text-foreground">Total Pending</span>
            <span className="text-lg font-bold text-destructive">
              UGX {salaryStats.totalPendingAmount.toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Total Paid</span>
            <span className="text-sm font-medium text-green-600 dark:text-green-400">
              UGX {salaryStats.totalPaidAmount.toLocaleString()}
            </span>
          </div>
        </div>
        
        {/* Pending Teachers Preview */}
        {salaryStats.unpaidTeachers.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium flex items-center gap-1 text-foreground">
              <AlertTriangle className="h-4 w-4 text-orange-500" />
              Unpaid Teachers:
            </p>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {salaryStats.unpaidTeachers.map((teacher) => (
                <div key={teacher.id} className="flex justify-between items-center text-sm p-2 bg-destructive/10 dark:bg-destructive/20 rounded">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium text-foreground">{teacher.name}</span>
                  </div>
                  <span className="text-xs font-medium text-foreground">
                    UGX {Number(teacher.salary || 0).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
            {salaryStats.pendingTeachers > 5 && (
              <p className="text-xs text-muted-foreground">
                +{salaryStats.pendingTeachers - 5} more teachers
              </p>
            )}
          </div>
        )}
        
        <Button 
          onClick={() => navigate('/hr-payroll')} 
          className="w-full"
          variant={salaryStats.pendingTeachers > 0 ? "default" : "outline"}
        >
          {salaryStats.pendingTeachers > 0 ? 'Process Payments' : 'View Payroll'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default PendingSalariesWidget;
