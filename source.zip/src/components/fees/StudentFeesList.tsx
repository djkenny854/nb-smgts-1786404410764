import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Plus, Eye, RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import PaymentModal from './PaymentModal';

interface StudentFeesListProps {
  searchTerm: string;
}

const StudentFeesList: React.FC<StudentFeesListProps> = ({ searchTerm }) => {
  const [selectedStudentFee, setSelectedStudentFee] = useState<any>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  const { data: studentFees, isLoading, refetch } = useQuery({
    queryKey: ['student-fees', searchTerm],
    queryFn: async () => {
      let query = supabase
        .from('student_fees')
        .select(`
          *,
          students!inner(
            id,
            full_name,
            student_id,
            class,
            boarding_status,
            transport
          )
        `)
        .order('created_at', { ascending: false });

      if (searchTerm) {
        query = query.ilike('students.full_name', `%${searchTerm}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    refetchInterval: 30000,
  });

  const handleAddPayment = (studentFee: any) => {
    setSelectedStudentFee(studentFee);
    setIsPaymentModalOpen(true);
  };

  const handlePaymentSuccess = () => {
    refetch();
    setIsPaymentModalOpen(false);
    setSelectedStudentFee(null);
  };

  const getPaymentStatus = (totalPaid: number, totalAssignedFees: number) => {
    if (totalPaid >= totalAssignedFees && totalAssignedFees > 0) return 'Paid';
    if (totalPaid > 0) return 'Partial';
    return 'Unpaid';
  };

  const getPaymentProgress = (totalPaid: number, totalAssignedFees: number) => {
    if (totalAssignedFees === 0) return 0;
    return Math.min((totalPaid / totalAssignedFees) * 100, 100);
  };

  const CircularProgress = ({ progress, size = 40 }: { progress: number; size?: number }) => {
    const radius = (size - 4) / 2;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (progress / 100) * circumference;

    return (
      <div className="relative" style={{ width: size, height: size }}>
        <svg
          className="transform -rotate-90"
          width={size}
          height={size}
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="hsl(var(--border))"
            strokeWidth="2"
            fill="none"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={progress === 100 ? "hsl(var(--chart-2))" : progress > 0 ? "hsl(var(--primary))" : "hsl(var(--destructive))"}
            strokeWidth="2"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className="transition-all duration-300"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xs font-medium text-foreground">{Math.round(progress)}%</span>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center justify-between p-4 border border-border rounded-lg">
              <div className="space-y-2">
                <div className="h-4 bg-muted rounded animate-pulse w-48"></div>
                <div className="h-3 bg-muted rounded animate-pulse w-32"></div>
              </div>
              <div className="h-6 bg-muted rounded animate-pulse w-20"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!studentFees || studentFees.length === 0) {
    return (
      <div className="p-12 text-center text-muted-foreground">
        <div className="mb-4">
          <p className="text-lg">No student fees found</p>
          <p className="text-sm mt-2">
            {searchTerm ? 'Try adjusting your search terms' : 'Student fees will appear here when fee structures are assigned to students'}
          </p>
        </div>
        <Button
          onClick={() => refetch()}
          variant="outline"
          className="flex items-center gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-foreground">
          Student Fee Records ({studentFees.length})
        </h3>
        <Button
          onClick={() => refetch()}
          variant="outline"
          size="sm"
          className="flex items-center gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>
      
      <div className="space-y-4">
        {studentFees.map((studentFee: any) => {
          const student = studentFee.students;
          const paymentStatus = getPaymentStatus(studentFee.total_paid || 0, studentFee.total_assigned_fees || 0);
          const balance = (studentFee.total_assigned_fees || 0) - (studentFee.total_paid || 0);
          const progress = getPaymentProgress(studentFee.total_paid || 0, studentFee.total_assigned_fees || 0);
          
          const paymentStatusColor = {
            'Paid': 'bg-green-500/10 text-green-600 dark:text-green-400',
            'Partial': 'bg-primary/10 text-primary',
            'Unpaid': 'bg-destructive/10 text-destructive'
          }[paymentStatus] || 'bg-muted text-muted-foreground';

          return (
            <div key={studentFee.id} className="flex flex-col lg:flex-row lg:items-center justify-between p-4 border border-border rounded-lg bg-card hover:bg-accent/50 transition-colors gap-4">
              <div className="flex items-center gap-4">
                <CircularProgress progress={progress} />
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <h3 className="font-semibold text-foreground">{student.full_name}</h3>
                    <Badge className={paymentStatusColor}>
                      {paymentStatus}
                    </Badge>
                    <Badge variant="outline">
                      {student.class}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                    <span>ID: {student.student_id}</span>
                    <span>Total: UGX {(studentFee.total_assigned_fees || 0).toLocaleString()}</span>
                    <span>Paid: UGX {(studentFee.total_paid || 0).toLocaleString()}</span>
                    <span>Balance: UGX {balance.toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleAddPayment(studentFee)}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Payment
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                >
                  <Eye className="h-4 w-4" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      {selectedStudentFee && (
        <PaymentModal
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          studentFee={selectedStudentFee}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  );
};

export default StudentFeesList;
