
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Brain, Download, CheckCircle, Sparkles, Receipt } from 'lucide-react';
import AITextAnimation from '@/components/ui/ai-text-animation';
import AISkeleton from '@/components/ui/ai-skeleton';

interface AIReceiptGeneratorProps {
  paymentData: {
    studentName: string;
    amount: number;
    method: string;
    receiptNumber: string;
    date: string;
    notes?: string;
  };
  onComplete: () => void;
}

const AIReceiptGenerator: React.FC<AIReceiptGeneratorProps> = ({
  paymentData,
  onComplete
}) => {
  const [stage, setStage] = useState<'generating' | 'complete'>('generating');
  const [aiInsights, setAiInsights] = useState<string[]>([]);

  const aiGeneratingTexts = [
    "AI is analyzing payment details...",
    "Generating smart receipt format...",
    "Optimizing payment summary...",
    "Adding intelligent insights...",
    "Finalizing receipt design..."
  ];

  useEffect(() => {
    // Simulate AI processing
    const timer = setTimeout(() => {
      setAiInsights([
        "Payment processed during optimal hours",
        "Student has excellent payment history",
        "Recommended payment method for future",
        "Balance optimization suggestions available"
      ]);
      setStage('complete');
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  const downloadReceipt = () => {
    const receiptText = `
╔══════════════════════════════════════╗
║          SMART PAYMENT RECEIPT       ║
║            AI-Generated              ║
╠══════════════════════════════════════╣
║                                      ║
║ Receipt #: ${paymentData.receiptNumber}                ║
║ Date: ${paymentData.date}                    ║
║                                      ║
║ STUDENT INFORMATION                  ║
║ Name: ${paymentData.studentName}                 ║
║                                      ║
║ PAYMENT DETAILS                      ║
║ Amount: UGX ${paymentData.amount.toLocaleString()}              ║
║ Method: ${paymentData.method}                    ║
║                                      ║
${paymentData.notes ? `║ Notes: ${paymentData.notes}                  ║` : ''}
║                                      ║
║ AI INSIGHTS                          ║
${aiInsights.map(insight => `║ • ${insight}    ║`).join('\n')}
║                                      ║
║ Thank you for your payment!          ║
║ Generated with AI assistance         ║
╚══════════════════════════════════════╝
    `;

    const blob = new Blob([receiptText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AI-Receipt-${paymentData.receiptNumber}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (stage === 'generating') {
    return (
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-indigo-50">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-purple-700">
            <Brain className="h-6 w-6 animate-pulse" />
            AI Receipt Generator
            <Sparkles className="h-4 w-4 text-purple-500" />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <AITextAnimation 
              texts={aiGeneratingTexts}
              className="text-purple-600 font-medium"
              interval={1500}
            />
          </div>
          
          <AISkeleton 
            lines={4} 
            message="Creating intelligent receipt..."
            className="bg-white/50 p-4 rounded-lg"
          />
          
          <div className="flex justify-center">
            <div className="flex space-x-2">
              {[...Array(5)].map((_, i) => (
                <div
                  key={i}
                  className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"
                  style={{ animationDelay: `${i * 0.1}s` }}
                />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 animate-scale-in">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2 text-green-700">
          <CheckCircle className="h-6 w-6" />
          AI-Generated Receipt Ready!
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <div className="text-center mb-4">
            <Receipt className="h-8 w-8 mx-auto text-green-600 mb-2" />
            <h3 className="font-bold text-lg">Smart Payment Receipt</h3>
            <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-300">
              AI-Enhanced
            </Badge>
          </div>
          
          <Separator className="my-4" />
          
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Receipt Number:</span>
              <span className="font-medium">{paymentData.receiptNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Student:</span>
              <span className="font-medium">{paymentData.studentName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Amount:</span>
              <span className="font-bold text-green-600">UGX {paymentData.amount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Method:</span>
              <span className="font-medium">{paymentData.method}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Date:</span>
              <span className="font-medium">{paymentData.date}</span>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div className="bg-purple-50 p-3 rounded-md">
            <h4 className="font-medium text-purple-700 mb-2 flex items-center gap-1">
              <Brain className="h-4 w-4" />
              AI Insights
            </h4>
            <ul className="text-xs space-y-1">
              {aiInsights.map((insight, index) => (
                <li key={index} className="flex items-center gap-2 text-purple-600">
                  <Sparkles className="h-3 w-3" />
                  {insight}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex gap-3">
          <Button onClick={downloadReceipt} className="flex-1" variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Download Receipt
          </Button>
          <Button onClick={onComplete} className="flex-1 bg-green-600 hover:bg-green-700">
            Complete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AIReceiptGenerator;
