import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, CreditCard, DollarSign, Brain, Sparkles } from 'lucide-react';
import AIPaymentInsights from './AIPaymentInsights';
import PaymentFormSkeleton from './PaymentFormSkeleton';
import PaymentConfirmationDialog from './PaymentConfirmationDialog';
import AIReceiptGenerator from './AIReceiptGenerator';
import AITextAnimation from '@/components/ui/ai-text-animation';
import AISkeleton from '@/components/ui/ai-skeleton';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentFee: any;
  onSuccess: () => void;
}

const PaymentModal = ({ isOpen, onClose, studentFee, onSuccess }: PaymentModalProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showAIReceipt, setShowAIReceipt] = useState(false);
  const [receiptData, setReceiptData] = useState<any>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [formData, setFormData] = useState({
    amount: '',
    payment_method: 'Cash',
    notes: '',
    receipt_number: ''
  });

  const student = studentFee?.students;
  const balance = (studentFee?.total_assigned_fees || 0) - (studentFee?.total_paid || 0);

  const aiSuggestionTexts = [
    "Analyzing payment patterns...",
    "Calculating optimal payment amounts...",
    "Reviewing student payment history...",
    "Generating smart recommendations..."
  ];

  useEffect(() => {
    if (isOpen && studentFee) {
      setIsInitializing(true);
      setTimeout(() => {
        setIsInitializing(false);
      }, 2000);
    }
  }, [isOpen, studentFee]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      toast.error('Please enter a valid payment amount');
      return;
    }

    if (parseFloat(formData.amount) > balance) {
      toast.error('Payment amount cannot exceed the outstanding balance');
      return;
    }

    // Show confirmation dialog instead of processing immediately
    setShowConfirmation(true);
  };

  const handleConfirmPayment = async () => {
    setShowConfirmation(false);
    setIsLoading(true);

    try {
      const receiptNumber = formData.receipt_number || `REC-${Date.now()}`;
      const paymentAmount = parseFloat(formData.amount);

      const { data: transactionData, error } = await supabase
        .from('fee_transactions')
        .insert([{
          student_id: studentFee.student_id,
          student_fee_id: studentFee.id,
          amount: paymentAmount,
          payment_method: formData.payment_method,
          notes: formData.notes,
          receipt_number: receiptNumber,
          academic_year: studentFee.academic_year,
          academic_term: studentFee.academic_term,
          status: 'completed'
        }])
        .select()
        .single();

      if (error) throw error;

      // Generate AI receipt data
      setReceiptData({
        studentName: student?.full_name,
        amount: paymentAmount,
        method: formData.payment_method,
        receiptNumber: receiptNumber,
        date: new Date().toLocaleDateString(),
        notes: formData.notes
      });

      toast.success('Payment recorded successfully!', {
        description: `UGX ${paymentAmount.toLocaleString()} recorded for ${student?.full_name}`
      });
      
      setShowAIReceipt(true);
      onSuccess();

    } catch (error: any) {
      console.error('Error recording payment:', error);
      toast.error('Failed to record payment', {
        description: error.message || 'Please try again'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestionApply = (amount: number) => {
    setFormData(prev => ({ ...prev, amount: amount.toString() }));
  };

  const handleAIReceiptComplete = () => {
    setShowAIReceipt(false);
    onClose();
  };

  if (showAIReceipt && receiptData) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <AIReceiptGenerator 
            paymentData={receiptData}
            onComplete={handleAIReceiptComplete}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-blue-600" />
              Record Payment - {student?.full_name}
              <div className="ml-auto">
                <AITextAnimation 
                  texts={["Smart Payment System", "AI-Enhanced", "Intelligent Processing"]}
                  className="text-sm text-purple-600"
                  showIcon={false}
                />
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Payment Form */}
            <div className="lg:col-span-3 space-y-4">
              {isInitializing ? (
                <div className="space-y-4">
                  <PaymentFormSkeleton />
                  <AISkeleton 
                    lines={2} 
                    message="AI is preparing smart payment options..."
                    className="bg-purple-50 p-4 rounded-lg"
                  />
                </div>
              ) : (
                <>
                  <Card className="border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50">
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold flex items-center gap-2">
                          <Brain className="h-4 w-4 text-purple-600" />
                          Smart Fee Summary
                        </h3>
                        <Badge variant="outline" className="bg-purple-100 text-purple-700">
                          {studentFee?.payment_status}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Total Required:</span>
                          <p className="font-semibold">UGX {(studentFee?.total_assigned_fees || 0).toLocaleString()}</p>
                        </div>
                        <div>
                          <span className="text-gray-600">Paid:</span>
                          <p className="font-semibold text-green-600">UGX {(studentFee?.total_paid || 0).toLocaleString()}</p>
                        </div>
                        <div className="col-span-2">
                          <span className="text-gray-600">Outstanding Balance:</span>
                          <p className="font-bold text-red-600 text-lg flex items-center gap-2">
                            UGX {balance.toLocaleString()}
                            <Sparkles className="h-4 w-4 text-purple-500" />
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="amount">Payment Amount (UGX)</Label>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="Enter amount"
                        value={formData.amount}
                        onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value }))}
                        max={balance}
                        required
                        className="text-lg font-medium"
                      />
                      {formData.amount && parseFloat(formData.amount) > balance && (
                        <p className="text-sm text-red-600">Amount exceeds outstanding balance</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="payment_method">Payment Method</Label>
                      <Select value={formData.payment_method} onValueChange={(value) => setFormData(prev => ({ ...prev, payment_method: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Cash">Cash</SelectItem>
                          <SelectItem value="Mobile Money">Mobile Money</SelectItem>
                          <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                          <SelectItem value="Cheque">Cheque</SelectItem>
                          <SelectItem value="Card">Card Payment</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="receipt_number">Receipt Number (Optional)</Label>
                      <Input
                        id="receipt_number"
                        placeholder="Auto-generated if empty"
                        value={formData.receipt_number}
                        onChange={(e) => setFormData(prev => ({ ...prev, receipt_number: e.target.value }))}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea
                        id="notes"
                        placeholder="Additional notes about this payment..."
                        value={formData.notes}
                        onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={isLoading || !formData.amount || parseFloat(formData.amount) > balance} 
                        className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <DollarSign className="mr-2 h-4 w-4" />
                            Review Payment
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </>
              )}
            </div>

            {/* AI Suggestions Panel */}
            <div className="lg:col-span-2">
              {isInitializing ? (
                <div className="space-y-4">
                  <Card className="border-purple-200">
                    <CardContent className="p-4">
                      <AITextAnimation 
                        texts={aiSuggestionTexts}
                        className="text-purple-600 font-medium mb-4"
                      />
                      <AISkeleton lines={3} showIcon={false} />
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <AIPaymentInsights 
                  studentFee={studentFee} 
                  onSuggestionApply={handleSuggestionApply}
                />
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Confirmation Dialog */}
      <PaymentConfirmationDialog
        open={showConfirmation}
        onOpenChange={setShowConfirmation}
        onConfirm={handleConfirmPayment}
        paymentData={{
          studentName: student?.full_name || '',
          amount: parseFloat(formData.amount) || 0,
          method: formData.payment_method,
          notes: formData.notes
        }}
        isProcessing={isLoading}
      />
    </>
  );
};

export default PaymentModal;
