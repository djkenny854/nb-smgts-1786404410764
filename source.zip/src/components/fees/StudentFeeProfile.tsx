
import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAllActiveStudents, getStudentFeesForTerm, getStudentTransactions } from "@/utils/feesService";
import { Button } from "@/components/ui/button";
import { Printer, MessageSquare } from "lucide-react";

export default function StudentFeeProfile({ externalStudentId }: { externalStudentId?: string | null }) {
  const [studentId, setStudentId] = useState<string | null>(externalStudentId ?? null);
  
  const { data: students = [] } = useQuery({
    queryKey: ["all_students"],
    queryFn: getAllActiveStudents,
  });
  
  const { data: fee } = useQuery({
    queryKey: ["student_fees", studentId],
    queryFn: () => (studentId ? getStudentFeesForTerm(studentId) : Promise.resolve(null)),
    enabled: !!studentId,
  });
  
  const { data: txns = [] } = useQuery({
    queryKey: ["fee_transactions", studentId],
    queryFn: () => (studentId ? getStudentTransactions(studentId) : Promise.resolve([])),
    enabled: !!studentId,
  });

  const selectedStudentName = studentId ? students.find(s => s.id === studentId)?.full_name : '';

  return (
    <div className="p-4 bg-white dark:bg-slate-800 rounded w-full max-w-xl mx-auto">
      <h2 className="text-xl font-bold mb-2">Student Fee Profile</h2>
      
      <select
        value={studentId ?? ""}
        onChange={(e) => setStudentId(e.target.value)}
        className="block w-full mb-4 px-2 py-2 rounded border"
      >
        <option value="">-- Select Student --</option>
        {students.map((s) => (
          <option key={s.id} value={s.id}>{s.full_name}</option>
        ))}
      </select>

      {studentId && !fee && (
        <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded">
          <p className="text-yellow-800 text-sm">
            No fee record found for {selectedStudentName}. This student needs to be assigned fees.
          </p>
        </div>
      )}
      
      {fee && (
        <div className="mb-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-900">
          <h3 className="font-semibold mb-2">Fee Summary</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span>Total Assigned:</span>
              <span className="font-semibold">{Number(fee.total_assigned_fees).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Total Paid:</span>
              <span className="font-semibold text-green-600">{Number(fee.total_paid).toLocaleString()}</span>
            </div>
            <div className="flex justify-between border-t pt-1">
              <span>Balance:</span>
              <span className="font-bold text-red-600">{Number(fee.balance).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span>Status:</span>
              <span className={`font-semibold ${
                fee.payment_status === 'Paid' ? 'text-green-600' : 
                fee.payment_status === 'Partial' ? 'text-yellow-600' : 'text-red-600'
              }`}>
                {fee.payment_status}
              </span>
            </div>
          </div>
          
          <div className="mt-3 flex gap-2">
            <Button className="flex-1" variant="outline" onClick={() => window.print()}>
              <Printer className="inline mr-1 w-4 h-4" /> 
              Print Receipt
            </Button>
            <Button className="flex-1" variant="outline" onClick={() => alert("SMS feature not yet implemented")}>
              <MessageSquare className="inline mr-1 w-4 h-4" />
              Send SMS
            </Button>
          </div>
        </div>
      )}
      
      <div>
        <h3 className="font-semibold mb-2">Payment History</h3>
        <div className="max-h-60 overflow-y-auto">
          <ul className="divide-y">
            {txns.length > 0 ? txns.map(t => (
              <li key={t.id} className="py-2 flex justify-between items-center">
                <div>
                  <div className="font-medium">{t.payment_date?.slice(0, 10)}</div>
                  <div className="text-sm text-gray-500">{t.payment_method}</div>
                  {t.notes && <div className="text-xs text-gray-400">{t.notes}</div>}
                </div>
                <div className="font-semibold text-green-600">
                  +{Number(t.amount).toLocaleString()}
                </div>
              </li>
            )) : (
              <li className="py-4 text-center text-gray-500">
                No payments recorded.
              </li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
