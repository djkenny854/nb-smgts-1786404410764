
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface FeeAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: any;
  onSuccess: () => void;
}

interface FeeStructure {
  id: string;
  name: string;
  academic_year: string;
  academic_term: string;
  tuition_fee: number;
  boarding_fee: number;
  transport_fee: number;
  meal_fee: number;
  activity_fee: number;
  library_fee: number;
  computer_fee: number;
  medical_fee: number;
  development_fee: number;
  exam_fee: number;
  uniform_fee: number;
  misc_fee: number;
}

const FeeAssignmentModal: React.FC<FeeAssignmentModalProps> = ({
  isOpen,
  onClose,
  student,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>([]);
  const [selectedStructure, setSelectedStructure] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      fetchFeeStructures();
    }
  }, [isOpen]);

  const fetchFeeStructures = async () => {
    try {
      const { data, error } = await supabase
        .from('fee_structures')
        .select('*')
        .order('academic_year', { ascending: false });

      if (error) throw error;
      setFeeStructures(data || []);
    } catch (error) {
      console.error('Error fetching fee structures:', error);
      toast({
        title: "Error",
        description: "Failed to fetch fee structures",
        variant: "destructive"
      });
    }
  };

  const calculateTotalFee = (structure: FeeStructure) => {
    let total = structure.tuition_fee || 0;
    
    // Add boarding fee if student is a boarder
    if (student.boarding_status === 'Boarding') {
      total += structure.boarding_fee || 0;
    }
    
    // Add transport fee if student uses transport
    if (student.transport === 'Yes') {
      total += structure.transport_fee || 0;
    }
    
    // Add other fees
    total += (structure.meal_fee || 0) +
             (structure.activity_fee || 0) +
             (structure.library_fee || 0) +
             (structure.computer_fee || 0) +
             (structure.medical_fee || 0) +
             (structure.development_fee || 0) +
             (structure.exam_fee || 0) +
             (structure.uniform_fee || 0) +
             (structure.misc_fee || 0);
    
    return total;
  };

  const handleAssignFee = async () => {
    if (!selectedStructure) {
      toast({
        title: "Error",
        description: "Please select a fee structure",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const structure = feeStructures.find(s => s.id === selectedStructure);
      if (!structure) throw new Error('Fee structure not found');

      const totalFee = calculateTotalFee(structure);

      const { error } = await supabase
        .from('student_fees')
        .insert([{
          student_id: student.id,
          fee_structure_id: structure.id,
          academic_year: structure.academic_year,
          academic_term: structure.academic_term,
          total_assigned_fees: totalFee,
          total_paid: 0,
          balance: totalFee,
          payment_status: 'Unpaid'
        }]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Fee structure assigned successfully"
      });

      onSuccess();
      onClose();
    } catch (error: any) {
      console.error('Error assigning fee structure:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to assign fee structure",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (!student) return null;

  const selectedStructureData = feeStructures.find(s => s.id === selectedStructure);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white border-gray-200 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-gray-900">Assign Fee Structure</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Student Info */}
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h3 className="font-semibold text-gray-900">{student.full_name}</h3>
            <div className="text-sm text-gray-600 space-y-1">
              <p>Student ID: {student.student_id}</p>
              <p>Class: {student.class}</p>
              <p>Boarding: {student.boarding_status}</p>
              <p>Transport: {student.transport}</p>
            </div>
          </div>

          {/* Fee Structure Selection */}
          <div className="space-y-2">
            <Label htmlFor="fee_structure" className="text-gray-700">Fee Structure *</Label>
            <Select value={selectedStructure} onValueChange={setSelectedStructure}>
              <SelectTrigger className="bg-white border-gray-300">
                <SelectValue placeholder="Select fee structure" />
              </SelectTrigger>
              <SelectContent className="bg-white border-gray-300">
                {feeStructures.map((structure) => (
                  <SelectItem key={structure.id} value={structure.id}>
                    {structure.name} - {structure.academic_year} {structure.academic_term}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Fee Preview */}
          {selectedStructureData && (
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <h4 className="font-medium text-blue-900 mb-2">Fee Breakdown</h4>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span>Tuition Fee:</span>
                  <span>UGX {(selectedStructureData.tuition_fee || 0).toLocaleString()}</span>
                </div>
                {student.boarding_status === 'Boarding' && (
                  <div className="flex justify-between">
                    <span>Boarding Fee:</span>
                    <span>UGX {(selectedStructureData.boarding_fee || 0).toLocaleString()}</span>
                  </div>
                )}
                {student.transport === 'Yes' && (
                  <div className="flex justify-between">
                    <span>Transport Fee:</span>
                    <span>UGX {(selectedStructureData.transport_fee || 0).toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Other Fees:</span>
                  <span>UGX {((selectedStructureData.meal_fee || 0) + 
                    (selectedStructureData.activity_fee || 0) + 
                    (selectedStructureData.library_fee || 0) + 
                    (selectedStructureData.computer_fee || 0) + 
                    (selectedStructureData.medical_fee || 0) + 
                    (selectedStructureData.development_fee || 0) + 
                    (selectedStructureData.exam_fee || 0) + 
                    (selectedStructureData.uniform_fee || 0) + 
                    (selectedStructureData.misc_fee || 0)).toLocaleString()}</span>
                </div>
                <div className="flex justify-between border-t pt-2 font-semibold">
                  <span>Total:</span>
                  <span>UGX {calculateTotalFee(selectedStructureData).toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleAssignFee}
              disabled={loading || !selectedStructure}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {loading ? 'Assigning...' : 'Assign Fee Structure'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FeeAssignmentModal;
