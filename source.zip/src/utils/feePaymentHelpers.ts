
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface FeePaymentData {
  amount: number;
  paymentMethod: string;
  notes?: string;
  academicYear: string;
  academicTerm: string;
}

export const recordFeePayment = async (studentId: string, paymentData: FeePaymentData) => {
  try {
    // First, get or create student fees record
    let { data: studentFees, error: studentFeesError } = await supabase
      .from('student_fees')
      .select('*')
      .eq('student_id', studentId)
      .eq('academic_year', paymentData.academicYear)
      .eq('academic_term', paymentData.academicTerm)
      .maybeSingle();

    if (studentFeesError) throw studentFeesError;

    // If no student fees record exists, create one with default fee structure
    if (!studentFees) {
      // Get student details
      const { data: student, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();

      if (studentError) throw studentError;

      // Calculate fees based on student status
      let feeAmount = 500000; // Base tuition
      
      if (student.boarding_status === 'Boarding') {
        feeAmount += 300000;
      }
      
      if (student.transport === 'Yes') {
        feeAmount += 50000;
      }
      
      feeAmount += 25000; // Activities

      // Create student fees record (balance will be auto-calculated)
      const { data: newStudentFees, error: createError } = await supabase
        .from('student_fees')
        .insert({
          student_id: studentId,
          total_assigned_fees: feeAmount,
          total_paid: 0,
          academic_year: paymentData.academicYear,
          academic_term: paymentData.academicTerm,
          payment_status: 'Unpaid'
        })
        .select()
        .single();

      if (createError) throw createError;
      studentFees = newStudentFees;
    }

    // Record the fee transaction
    const { data: transaction, error: transactionError } = await supabase
      .from('fee_transactions')
      .insert({
        student_id: studentId,
        student_fee_id: studentFees.id,
        amount: paymentData.amount,
        payment_method: paymentData.paymentMethod,
        notes: paymentData.notes || '',
        academic_year: paymentData.academicYear,
        academic_term: paymentData.academicTerm
      })
      .select()
      .single();

    if (transactionError) throw transactionError;

    // Update the student fees record (balance will be auto-calculated)
    const { error: updateError } = await supabase
      .from('student_fees')
      .update({
        total_paid: (studentFees.total_paid || 0) + paymentData.amount,
        updated_at: new Date().toISOString()
      })
      .eq('id', studentFees.id);

    if (updateError) throw updateError;

    // Update the student's fee status for quick access
    const newTotalPaid = (studentFees.total_paid || 0) + paymentData.amount;
    const feeStatus = newTotalPaid >= (studentFees.total_assigned_fees || 0) ? 'Paid' : newTotalPaid > 0 ? 'Partial' : 'Unpaid';
    
    const { error: studentUpdateError } = await supabase
      .from('students')
      .update({
        fee_status: feeStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', studentId);

    if (studentUpdateError) {
      console.warn('Failed to update student fee status:', studentUpdateError);
    }

    console.log('Fee payment recorded successfully:', transaction);
    return transaction;

  } catch (error) {
    console.error('Error recording fee payment:', error);
    throw error;
  }
};

export const getStudentFeesSummary = async (studentId: string, academicYear?: string, academicTerm?: string) => {
  try {
    let query = supabase
      .from('student_fees')
      .select(`
        *,
        fee_structures(*),
        fee_transactions(*)
      `)
      .eq('student_id', studentId);

    if (academicYear) {
      query = query.eq('academic_year', academicYear);
    }
    if (academicTerm) {
      query = query.eq('academic_term', academicTerm);
    }

    const { data, error } = await query;
    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Error fetching student fees summary:', error);
    throw error;
  }
};

export const getStudentPaymentHistory = async (studentId: string, limit: number = 10) => {
  try {
    const { data, error } = await supabase
      .from('fee_transactions')
      .select('*')
      .eq('student_id', studentId)
      .order('payment_date', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching student payment history:', error);
    throw error;
  }
};

export const updateStudentFeesFromTransaction = async (studentId: string, academicYear: string, academicTerm: string) => {
  try {
    // Calculate total paid from all transactions
    const { data: transactions, error: transError } = await supabase
      .from('fee_transactions')
      .select('amount')
      .eq('student_id', studentId)
      .eq('academic_year', academicYear)
      .eq('academic_term', academicTerm);

    if (transError) throw transError;

    const totalPaid = transactions?.reduce((sum, t) => sum + (t.amount || 0), 0) || 0;

    // Get student fees record
    const { data: studentFees, error: feesError } = await supabase
      .from('student_fees')
      .select('*')
      .eq('student_id', studentId)
      .eq('academic_year', academicYear)
      .eq('academic_term', academicTerm)
      .single();

    if (feesError) throw feesError;

    // Update student fees (balance will be auto-calculated)
    const { error: updateError } = await supabase
      .from('student_fees')
      .update({
        total_paid: totalPaid,
        updated_at: new Date().toISOString()
      })
      .eq('id', studentFees.id);

    if (updateError) throw updateError;

    // Calculate balance manually for return value
    const balance = (studentFees.total_assigned_fees || 0) - totalPaid;

    // Update student fee status
    const feeStatus = balance <= 0 ? 'Paid' : balance < (studentFees.total_assigned_fees || 0) ? 'Partial' : 'Unpaid';
    
    const { error: studentUpdateError } = await supabase
      .from('students')
      .update({
        fee_status: feeStatus,
        updated_at: new Date().toISOString()
      })
      .eq('id', studentId);

    if (studentUpdateError) {
      console.warn('Failed to update student fee status:', studentUpdateError);
    }

    return { totalPaid, balance, feeStatus };
  } catch (error) {
    console.error('Error updating student fees from transaction:', error);
    throw error;
  }
};
