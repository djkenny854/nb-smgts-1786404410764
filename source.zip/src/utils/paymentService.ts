
import { supabase } from '@/lib/supabase';
import { Payment, PaymentMethod, PaymentStats } from '@/types/payment';
import { v4 as uuidv4 } from 'uuid';

export interface AddPaymentParams {
  studentId: string;
  studentName?: string;
  amount: number;
  method: PaymentMethod;
  description: string;
  receivedBy: string;
  academicTerm: string;
  academicYear: string;
}

export const addPayment = async (paymentData: AddPaymentParams): Promise<Payment> => {
  const payment: Payment = {
    id: uuidv4(),
    ...paymentData,
    createdAt: new Date().toISOString(),
  };

  console.log('Adding payment:', payment);

  const { data, error } = await supabase
    .from('payments')
    .insert(payment)
    .select()
    .single();

  if (error) {
    console.error('Error adding payment:', error);
    throw error;
  }

  console.log('Payment added successfully:', data);
  return data as Payment;
};

export const getStudentPayments = async (studentId: string): Promise<Payment[]> => {
  const { data, error } = await supabase
    .from('payments')
    .select('*')
    .eq('studentId', studentId)
    .order('createdAt', { ascending: false });

  if (error) {
    console.error('Error fetching student payments:', error);
    throw error;
  }

  return data as Payment[];
};

export const getTotalPaymentsByStudent = async (studentId: string): Promise<number> => {
  const payments = await getStudentPayments(studentId);
  return payments.reduce((total, payment) => total + payment.amount, 0);
};

export const getPaymentStats = async (filter?: { 
  startDate?: string, 
  endDate?: string,
  academicTerm?: string,
  academicYear?: string
}): Promise<PaymentStats> => {
  let query = supabase.from('payments').select('amount, createdAt');
  
  if (filter?.startDate) {
    query = query.gte('createdAt', filter.startDate);
  }
  
  if (filter?.endDate) {
    query = query.lte('createdAt', filter.endDate);
  }
  
  if (filter?.academicTerm) {
    query = query.eq('academicTerm', filter.academicTerm);
  }
  
  if (filter?.academicYear) {
    query = query.eq('academicYear', filter.academicYear);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Error fetching payment stats:', error);
    throw error;
  }
  
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
  const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay())).toISOString();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
  const startOfYear = new Date(now.getFullYear(), 0, 1).toISOString();
  
  return {
    daily: calculateTotalForPeriod(data, startOfDay),
    weekly: calculateTotalForPeriod(data, startOfWeek),
    monthly: calculateTotalForPeriod(data, startOfMonth),
    termly: data
      .filter(payment => payment.academicTerm === filter?.academicTerm)
      .reduce((total, payment) => total + payment.amount, 0),
    yearly: calculateTotalForPeriod(data, startOfYear),
  };
};

const calculateTotalForPeriod = (payments: any[], startDate: string): number => {
  return payments
    .filter(payment => new Date(payment.createdAt) >= new Date(startDate))
    .reduce((total, payment) => total + payment.amount, 0);
};
