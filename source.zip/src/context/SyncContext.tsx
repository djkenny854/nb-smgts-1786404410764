
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SyncStatus } from '@/types';

type SyncContextType = {
  syncStatus: SyncStatus;
  triggerSync: () => Promise<void>;
  exportData: () => Promise<Blob>;
  importData: (file: File) => Promise<void>;
};

// Default sync status
const defaultSyncStatus: SyncStatus = {
  lastSyncedAt: null,
  syncedWithDevices: [],
  pendingChanges: 0,
  status: 'offline',
};

const SyncContext = createContext<SyncContextType>({
  syncStatus: defaultSyncStatus,
  triggerSync: async () => {},
  exportData: async () => new Blob(),
  importData: async () => {},
});

export const useSync = () => useContext(SyncContext);

export const SyncProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(defaultSyncStatus);

  // Simulating occasional sync status changes
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly change sync status for demo purposes
      const statuses: SyncStatus['status'][] = ['synced', 'syncing', 'offline', 'error'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      
      if (randomStatus === 'synced') {
        setSyncStatus({
          lastSyncedAt: new Date().toISOString(),
          syncedWithDevices: ['Teacher Laptop 1', 'Principal Office'],
          pendingChanges: 0,
          status: randomStatus,
        });
      } else if (randomStatus === 'syncing') {
        setSyncStatus({
          lastSyncedAt: syncStatus.lastSyncedAt,
          syncedWithDevices: ['Teacher Laptop 1', 'Principal Office'],
          pendingChanges: 0,
          status: randomStatus,
        });
      } else if (randomStatus === 'offline') {
        setSyncStatus({
          lastSyncedAt: syncStatus.lastSyncedAt,
          syncedWithDevices: [],
          pendingChanges: Math.floor(Math.random() * 10),
          status: randomStatus,
        });
      } else {
        setSyncStatus({
          lastSyncedAt: syncStatus.lastSyncedAt,
          syncedWithDevices: [],
          pendingChanges: Math.floor(Math.random() * 10),
          status: randomStatus,
        });
      }
    }, 30000); // Change status every 30 seconds

    return () => clearInterval(interval);
  }, [syncStatus]);

  const triggerSync = async () => {
    try {
      setSyncStatus({
        ...syncStatus,
        status: 'syncing',
      });

      // Simulate network request
      await new Promise(resolve => setTimeout(resolve, 2000));

      setSyncStatus({
        lastSyncedAt: new Date().toISOString(),
        syncedWithDevices: ['Teacher Laptop 1', 'Principal Office'],
        pendingChanges: 0,
        status: 'synced',
      });
    } catch (error) {
      setSyncStatus({
        ...syncStatus,
        status: 'error',
      });
    }
  };

  const exportData = async (): Promise<Blob> => {
    // Mock data export
    const data = {
      students: [], // Would contain actual student data
      teachers: [], // Would contain actual teacher data
      classes: [], // Would contain actual class data
      // etc.
      exportedAt: new Date().toISOString(),
    };

    return new Blob([JSON.stringify(data, null, 2)], { 
      type: 'application/json' 
    });
  };

  const importData = async (file: File): Promise<void> => {
    try {
      // In a real app, would parse the file and update the database
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update sync status after successful import
      setSyncStatus({
        lastSyncedAt: new Date().toISOString(),
        syncedWithDevices: ['External Import'],
        pendingChanges: 0,
        status: 'synced',
      });
    } catch (error) {
      setSyncStatus({
        ...syncStatus,
        status: 'error',
      });
      throw new Error('Failed to import data');
    }
  };

  return (
    <SyncContext.Provider 
      value={{ 
        syncStatus, 
        triggerSync, 
        exportData, 
        importData 
      }}
    >
      {children}
    </SyncContext.Provider>
  );
};
