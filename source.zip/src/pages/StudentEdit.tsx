
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Student } from '@/types';
import StudentForm from '@/components/students/StudentForm';
import { StudentFormValues } from '@/components/students/form-sections/StudentFormSchema';

const StudentEdit = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchStudent(id);
    }
  }, [id]);

  const fetchStudent = async (studentId: string) => {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();

      if (error) throw error;

      if (data) {
        setStudent({
          id: data.id,
          name: data.full_name,
          enrollmentNumber: data.student_id,
          dateOfBirth: data.date_of_birth || '',
          gender: data.gender || '',
          classId: data.class,
          className: data.class,
          parentName: data.parent_name || '',
          parentContact: data.parent_contact || '',
          address: data.address || '',
          joinDate: data.join_date || '',
          fees: {
            paid: 0,
            due: 0,
            lastPaymentDate: null,
          },
          profileImage: data.profile_image_url || '',
          email: data.email || '',
          bloodGroup: data.blood_group || '',
          emergencyContact: data.emergency_contact || '',
          medicalConditions: data.medical_conditions || '',
          boardingStatus: (data.boarding_status as 'Boarding' | 'Day') || 'Day',
          transportUse: (data.transport as 'Yes' | 'No') || 'No',
          bestColor: data.best_color || '',
          clubsActivities: data.clubs_activities || [],
        });
      }
    } catch (error) {
      console.error('Error fetching student:', error);
      toast.error('Failed to load student data');
      navigate('/students');
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    toast.success('Student updated successfully!');
    navigate('/students');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading student data...</p>
        </div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-gray-600">Student not found</p>
        </div>
      </div>
    );
  }

  // Transform Student to StudentFormValues
  const initialFormData: Partial<StudentFormValues> = {
    name: student.name,
    enrollmentNumber: student.enrollmentNumber,
    className: student.className,
    dateOfBirth: student.dateOfBirth,
    gender: student.gender,
    parentName: student.parentName,
    parentContact: student.parentContact,
    address: student.address,
    joinDate: student.joinDate,
    boardingStatus: student.boardingStatus,
    transportUse: student.transportUse,
    email: student.email,
    bloodGroup: student.bloodGroup,
    emergencyContact: student.emergencyContact,
    medicalConditions: student.medicalConditions,
    bestColor: student.bestColor,
    clubsActivities: student.clubsActivities,
    profileImage: student.profileImage,
  };

  return (
    <div className="container mx-auto py-6">
      <StudentForm
        initialData={initialFormData}
        studentId={student.id}
        onSuccess={handleSuccess}
        mode="edit"
      />
    </div>
  );
};

export default StudentEdit;
