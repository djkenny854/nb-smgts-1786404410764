
import React, { useState, useEffect } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, Filter, Search, Calendar, Users, TrendingUp, Clock, CheckCircle, Eye, BarChart3 } from 'lucide-react';
import { AttendanceMarker } from '@/components/attendance/AttendanceMarker';
import AttendanceReports from '@/components/reports/AttendanceReports';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useMobile } from '@/hooks/use-mobile';
import { format, subDays, startOfMonth, endOfMonth } from 'date-fns';

interface AttendanceRecord {
  id: string;
  date: string;
  status: string;
  student_id: string;
  students: {
    full_name: string;
    student_id: string;
    class: string;
  };
}

interface AttendanceSummary {
  date: string;
  class_name: string;
  total_students: number;
  present: number;
  absent: number;
  late: number;
  excused: number;
  attendance_rate: number;
}

const AttendancePage = () => {
  const [activeTab, setActiveTab] = useState('take');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState('all');
  const [selectedDateRange, setSelectedDateRange] = useState('week');
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [attendanceSummary, setAttendanceSummary] = useState<AttendanceSummary[]>([]);
  const [classes, setClasses] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [overallStats, setOverallStats] = useState({
    totalStudents: 0,
    presentToday: 0,
    absentToday: 0,
    attendanceRate: 0
  });
  const { toast } = useToast();
  const isMobile = useMobile();

  useEffect(() => {
    fetchClasses();
    fetchOverallStats();
  }, []);

  useEffect(() => {
    if (activeTab === 'view') {
      fetchAttendanceRecords();
    } else if (activeTab === 'reports') {
      fetchAttendanceSummary();
    }
  }, [activeTab, selectedClass, selectedDateRange, searchQuery]);

  const fetchClasses = async () => {
    try {
      const { data, error } = await supabase
        .from('available_classes')
        .select('class_name')
        .order('class_name');

      if (error) throw error;
      setClasses(data?.map(c => c.class_name) || []);
    } catch (error) {
      console.error('Error fetching classes:', error);
    }
  };

  const fetchOverallStats = async () => {
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      
      // Get total students
      const { data: students, error: studentsError } = await supabase
        .from('students')
        .select('id');

      if (studentsError) throw studentsError;

      // Get today's attendance
      const { data: todayAttendance, error: attendanceError } = await supabase
        .from('attendance')
        .select('status')
        .eq('date', today);

      if (attendanceError) throw attendanceError;

      const totalStudents = students?.length || 0;
      const presentToday = todayAttendance?.filter(a => a.status === 'present').length || 0;
      const absentToday = todayAttendance?.filter(a => a.status === 'absent').length || 0;
      const attendanceRate = totalStudents > 0 ? Math.round((presentToday / totalStudents) * 100) : 0;

      setOverallStats({
        totalStudents,
        presentToday,
        absentToday,
        attendanceRate
      });
    } catch (error) {
      console.error('Error fetching overall stats:', error);
    }
  };

  const getDateRange = () => {
    const now = new Date();
    switch (selectedDateRange) {
      case 'today':
        return { start: now, end: now };
      case 'week':
        return { start: subDays(now, 7), end: now };
      case 'month':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      default:
        return { start: subDays(now, 7), end: now };
    }
  };

  const fetchAttendanceRecords = async () => {
    try {
      setLoading(true);
      const { start, end } = getDateRange();
      
      let query = supabase
        .from('attendance')
        .select(`
          *,
          students (
            full_name,
            student_id,
            class
          )
        `)
        .gte('date', format(start, 'yyyy-MM-dd'))
        .lte('date', format(end, 'yyyy-MM-dd'))
        .order('date', { ascending: false });

      if (selectedClass !== 'all') {
        // First get student IDs from the selected class
        const { data: classStudents, error: classError } = await supabase
          .from('students')
          .select('id')
          .eq('class', selectedClass);

        if (classError) throw classError;
        
        if (classStudents && classStudents.length > 0) {
          query = query.in('student_id', classStudents.map(s => s.id));
        } else {
          setAttendanceRecords([]);
          return;
        }
      }

      const { data, error } = await query;

      if (error) throw error;

      let filteredData = data || [];

      // Filter by search query
      if (searchQuery) {
        filteredData = filteredData.filter(record =>
          record.students?.full_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          record.students?.student_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          record.students?.class.toLowerCase().includes(searchQuery.toLowerCase())
        );
      }

      setAttendanceRecords(filteredData);
    } catch (error) {
      console.error('Error fetching attendance records:', error);
      toast({
        title: "Error",
        description: "Failed to fetch attendance records",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAttendanceSummary = async () => {
    try {
      setLoading(true);
      const { start, end } = getDateRange();
      
      const { data, error } = await supabase
        .from('attendance')
        .select(`
          date,
          status,
          students (
            class
          )
        `)
        .gte('date', format(start, 'yyyy-MM-dd'))
        .lte('date', format(end, 'yyyy-MM-dd'));

      if (error) throw error;

      // Group by date and class
      const summaryMap = new Map<string, any>();
      
      data?.forEach(record => {
        const key = `${record.date}_${record.students.class}`;
        
        if (!summaryMap.has(key)) {
          summaryMap.set(key, {
            date: record.date,
            class_name: record.students.class,
            total_students: 0,
            present: 0,
            absent: 0,
            late: 0,
            excused: 0
          });
        }
        
        const summary = summaryMap.get(key);
        summary.total_students++;
        
        switch (record.status) {
          case 'present':
            summary.present++;
            break;
          case 'absent':
            summary.absent++;
            break;
          case 'late':
            summary.late++;
            break;
          case 'excused':
            summary.excused++;
            break;
        }
      });

      // Convert to array and calculate attendance rates
      const summaryArray = Array.from(summaryMap.values()).map(summary => ({
        ...summary,
        attendance_rate: summary.total_students > 0 
          ? Math.round(((summary.present + summary.late) / summary.total_students) * 100)
          : 0
      }));

      // Filter by class if selected
      const filteredSummary = selectedClass === 'all' 
        ? summaryArray 
        : summaryArray.filter(s => s.class_name === selectedClass);

      setAttendanceSummary(filteredSummary.sort((a, b) => b.date.localeCompare(a.date)));
    } catch (error) {
      console.error('Error fetching attendance summary:', error);
      toast({
        title: "Error",
        description: "Failed to fetch attendance summary",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const exportRecords = () => {
    const csvContent = [
      ['Date', 'Student Name', 'Student ID', 'Class', 'Status'],
      ...attendanceRecords.map(record => [
        record.date,
        record.students?.full_name || '',
        record.students?.student_id || '',
        record.students?.class || '',
        record.status
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_records_${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export Successful",
      description: "Attendance records exported successfully"
    });
  };

  const getStatusBadge = (status: string) => {
    const colors = {
      present: 'bg-green-100 text-green-800',
      absent: 'bg-red-100 text-red-800',
      late: 'bg-yellow-100 text-yellow-800',
      excused: 'bg-blue-100 text-blue-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  return (
    <MainLayout>
      <div className="flex flex-col space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold tracking-tight">Attendance Management</h1>
          <Button variant="outline" onClick={exportRecords}>
            <Download className="h-4 w-4 mr-2" />
            Export Reports
          </Button>
        </div>

        {/* Overall Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-blue-600" />
                <div>
                  <p className="text-2xl font-bold">{overallStats.totalStudents}</p>
                  <p className="text-xs text-muted-foreground">Total Students</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                <div>
                  <p className="text-2xl font-bold text-green-600">{overallStats.presentToday}</p>
                  <p className="text-xs text-muted-foreground">Present Today</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-red-600" />
                <div>
                  <p className="text-2xl font-bold text-red-600">{overallStats.absentToday}</p>
                  <p className="text-xs text-muted-foreground">Absent Today</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-primary" />
                <div>
                  <p className="text-2xl font-bold text-primary">{overallStats.attendanceRate}%</p>
                  <p className="text-xs text-muted-foreground">Attendance Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="take" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 w-full mb-4">
            <TabsTrigger value="take">
              <CheckCircle className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Take Attendance</span>}
            </TabsTrigger>
            <TabsTrigger value="view">
              <Eye className="h-4 w-4" />
              {!isMobile && <span className="ml-2">View Records</span>}
            </TabsTrigger>
            <TabsTrigger value="reports">
              <BarChart3 className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Reports & Analytics</span>}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="take" className="space-y-6">
            <AttendanceMarker />
          </TabsContent>
          
          <TabsContent value="view" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Attendance Records</CardTitle>
                <CardDescription>View and manage attendance records</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col sm:flex-row gap-4 justify-between">
                  <div className="flex gap-4">
                    <div className="relative w-full sm:w-64">
                      <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search records..."
                        className="pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    
                    <Select value={selectedClass} onValueChange={setSelectedClass}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="All Classes" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        {classes.map((className) => (
                          <SelectItem key={className} value={className}>
                            {className}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={selectedDateRange} onValueChange={setSelectedDateRange}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Range" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="today">Today</SelectItem>
                        <SelectItem value="week">This Week</SelectItem>
                        <SelectItem value="month">This Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button variant="outline" size="sm" onClick={exportRecords}>
                    <Download className="h-4 w-4 mr-1" />
                    Export
                  </Button>
                </div>
                
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Student Name</TableHead>
                        <TableHead>Student ID</TableHead>
                        <TableHead>Class</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-10">
                            <div className="flex items-center justify-center">
                              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent mr-2"></div>
                              Loading records...
                            </div>
                          </TableCell>
                        </TableRow>
                      ) : attendanceRecords.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                            No attendance records found for the selected criteria.
                          </TableCell>
                        </TableRow>
                      ) : (
                        attendanceRecords.map((record) => (
                          <TableRow key={record.id}>
                            <TableCell>{format(new Date(record.date), 'MMM dd, yyyy')}</TableCell>
                            <TableCell className="font-medium">{record.students?.full_name}</TableCell>
                            <TableCell>{record.students?.student_id}</TableCell>
                            <TableCell>{record.students?.class}</TableCell>
                            <TableCell className="text-center">
                              <Badge className={getStatusBadge(record.status)}>
                                {record.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="reports" className="space-y-6">
            <AttendanceReports />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default AttendancePage;
