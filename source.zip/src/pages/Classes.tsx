
import React, { useState, useEffect } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Users, ArrowLeft, Eye, Search, MoreHorizontal, ChevronRight, Grid3X3 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import SeatLayout from '@/components/classroom/SeatLayout';
import { useNavigate } from 'react-router-dom';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ClassData {
  class_name: string;
  student_count: number;
}

const Classes = () => {
  const [classes, setClasses] = useState<ClassData[]>([]);
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  const fetchClasses = async () => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('students')
        .select('class')
        .order('class');

      if (error) throw error;

      const classMap = new Map();
      data?.forEach(student => {
        const className = student.class;
        classMap.set(className, (classMap.get(className) || 0) + 1);
      });

      const classData = Array.from(classMap.entries()).map(([class_name, student_count]) => ({
        class_name,
        student_count
      }));

      setClasses(classData);
    } catch (error) {
      console.error('Error fetching classes:', error);
      toast({
        title: "Error",
        description: "Failed to load classes data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClasses();
  }, []);

  const filteredClasses = classes.filter(c => 
    c.class_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalStudents = classes.reduce((sum, c) => sum + c.student_count, 0);

  if (selectedClass) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Button
            variant="ghost"
            onClick={() => setSelectedClass(null)}
            className="flex items-center gap-2 rounded-full hover:bg-secondary"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <SeatLayout className={selectedClass} />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* Header - X.com style */}
        <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-border pb-4">
          <div className="mb-4">
            <h1 className="text-xl font-bold">Classes</h1>
            <p className="text-sm text-muted-foreground">
              {classes.length} classes · {totalStudents} students
            </p>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search classes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-secondary border-0 rounded-full focus-visible:ring-1 focus-visible:ring-primary"
            />
          </div>
        </div>

        {loading ? (
          <div className="space-y-1">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <div key={i} className="h-16 bg-card/50 rounded animate-pulse border-b border-border"></div>
            ))}
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filteredClasses.map((classData) => (
              <div
                key={classData.class_name}
                className="py-3 px-2 hover:bg-secondary/50 transition-colors cursor-pointer"
                onClick={() => navigate(`/classes/${encodeURIComponent(classData.class_name)}`)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {/* Icon */}
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Users className="h-5 w-5 text-primary" />
                    </div>

                    {/* Content */}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-foreground">{classData.class_name}</span>
                        {classData.student_count > 0 && (
                          <Badge variant="secondary" className="rounded-full text-xs px-2 py-0">
                            Active
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>{classData.student_count} students</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Quick Actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-primary/10 hover:text-primary">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/classes/${encodeURIComponent(classData.class_name)}`);
                        }}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          setSelectedClass(classData.class_name);
                        }}>
                          <Grid3X3 className="h-4 w-4 mr-2" />
                          Seat Layout
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                    
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!loading && filteredClasses.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
            <h3 className="font-semibold text-foreground mb-1">No classes found</h3>
            <p className="text-sm text-muted-foreground">
              {searchQuery ? 'Try a different search term' : 'Add students to see classes here'}
            </p>
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Classes;
