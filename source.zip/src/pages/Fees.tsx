import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import FeeManagementDashboard from '@/components/fees/FeeManagementDashboard';
import StudentPaymentRecorder from '@/components/fees/StudentPaymentRecorder';
import FeeStructureManager from '@/components/fees/FeeStructureManager';
import { DollarSign, LayoutDashboard, FileText, Wallet } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMobile } from '@/hooks/use-mobile';

const Fees = () => {
  const isMobile = useMobile();
  
  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="bg-card rounded-2xl p-6 border border-border">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold tracking-tight mb-2 text-foreground">
                Fee Management System
              </h1>
              <p className="text-muted-foreground">
                Complete fee management - structures, assignments, payments, and tracking
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <div className="p-3 bg-primary/10 rounded-full">
                <DollarSign size={40} className="text-primary" />
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dashboard">
              <LayoutDashboard className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Dashboard</span>}
            </TabsTrigger>
            <TabsTrigger value="structures">
              <FileText className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Fee Structures</span>}
            </TabsTrigger>
            <TabsTrigger value="payments">
              <Wallet className="h-4 w-4" />
              {!isMobile && <span className="ml-2">Record Payments</span>}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="dashboard" className="space-y-4">
            <FeeManagementDashboard />
          </TabsContent>
          
          <TabsContent value="structures" className="space-y-4">
            <FeeStructureManager />
          </TabsContent>
          
          <TabsContent value="payments" className="space-y-4">
            <StudentPaymentRecorder />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Fees;
