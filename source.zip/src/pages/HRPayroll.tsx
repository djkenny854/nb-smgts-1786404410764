
import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import StaffAttendance from '@/components/hr/StaffAttendance';
import LeaveManagement from '@/components/hr/LeaveManagement';
import PayrollManagement from '@/components/hr/PayrollManagement';

const HRPayroll = () => {
  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">HR & Payroll</h1>
          <p className="text-muted-foreground">
            Manage staff attendance, leave requests, and payroll processing.
          </p>
        </div>

        <Tabs defaultValue="attendance" className="space-y-4">
          <TabsList>
            <TabsTrigger value="attendance">Staff Attendance</TabsTrigger>
            <TabsTrigger value="leave">Leave Management</TabsTrigger>
            <TabsTrigger value="payroll">Payroll</TabsTrigger>
          </TabsList>

          <TabsContent value="attendance" className="space-y-4">
            <StaffAttendance />
          </TabsContent>

          <TabsContent value="leave" className="space-y-4">
            <LeaveManagement />
          </TabsContent>

          <TabsContent value="payroll" className="space-y-4">
            <PayrollManagement />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default HRPayroll;
