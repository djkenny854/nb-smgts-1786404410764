
import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import SubjectManagement from '@/components/subjects/SubjectManagement';

const Subjects = () => {
  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <SubjectManagement />
      </div>
    </MainLayout>
  );
};

export default Subjects;
