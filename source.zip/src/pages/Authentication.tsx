
import React from 'react';
import { Navigate } from 'react-router-dom';
import LoginForm from '@/components/auth/LoginForm';
import { useAuth } from '@/context/AuthContext';

const Authentication = () => {
  const { isAuthenticated, isLoading } = useAuth();
  
  // DEVELOPMENT MODE: Skip authentication checks - AUTHENTICATION DISABLED
  const devMode = true;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="w-full max-w-md p-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="p-4 rounded-full bg-primary/10">
              <div className="h-10 w-10 rounded-full border-3 border-primary border-t-transparent animate-spin" />
            </div>
            <p className="text-sm font-medium text-slate-600">Loading ClassPilot...</p>
          </div>
        </div>
      </div>
    );
  }

  // In development mode, always redirect to dashboard
  if (devMode) {
    return <Navigate to="/dashboard" />;
  }

  // Production mode: Check authentication
  if (isAuthenticated) {
    return <Navigate to="/" />;
  }

  return <LoginForm />;
};

export default Authentication;
