
import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import InventoryDashboard from '@/components/inventory/InventoryDashboard';
import InventoryList from '@/components/inventory/InventoryList';
import InventoryTransactions from '@/components/inventory/InventoryTransactions';
import InventoryReports from '@/components/inventory/InventoryReports';
import FeesUsageTracker from '@/components/inventory/FeesUsageTracker';

const Inventory = () => {
  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory Management</h1>
          <p className="text-muted-foreground">
            Manage school assets, track fee usage, and enable Google device enrollment.
          </p>
        </div>

        <Tabs defaultValue="dashboard" className="space-y-4">
          <TabsList>
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="items">Items</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="fees-usage">Fee Usage</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4">
            <InventoryDashboard />
          </TabsContent>

          <TabsContent value="items" className="space-y-4">
            <InventoryList />
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            <InventoryTransactions />
          </TabsContent>

          <TabsContent value="fees-usage" className="space-y-4">
            <FeesUsageTracker />
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <InventoryReports />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default Inventory;
