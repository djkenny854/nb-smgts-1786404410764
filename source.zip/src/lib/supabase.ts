
import { createClient } from '@supabase/supabase-js';

// These environment variables need to be set by the user after connecting to Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://nwaeyguvhidayxctdvpy.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im53YWV5Z3V2aGlkYXl4Y3RkdnB5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE3NDA4MTUsImV4cCI6MjA1NzMxNjgxNX0.kAZy7X-MnCKT3Kwk8JShersLFlVLQtx8oLstZsD63Y8';

console.log('Supabase URL:', supabaseUrl);
console.log('Supabase Anon Key:', supabaseAnonKey ? 'Provided' : 'Missing');

// Create a client, either real or mock
let supabase;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Missing Supabase credentials. Please connect your project to Supabase using the green Supabase button in the top-right corner.');
  
  // Create more robust mock methods to prevent runtime errors
  supabase = {
    from: () => ({
      select: () => ({ data: [], error: null }),
      insert: async (data: any) => {
        console.log('Mock insert:', data);
        return { data: { ...data, id: `mock-${Date.now()}` }, error: null };
      },
      update: () => ({ data: null, error: null }),
      delete: () => ({ data: null, error: null }),
      eq: () => ({ data: null, error: null }),
      single: () => ({ data: null, error: null }),
      order: () => ({ data: [], error: null }),
    }),
    auth: {
      getSession: async () => ({ 
        data: { session: null }, 
        error: null 
      }),
      signInWithPassword: async () => ({
        data: null,
        error: { message: 'Mock auth - Supabase not connected' }
      }),
      signOut: async () => ({ error: null }),
      onAuthStateChange: (callback: any) => ({
        data: { subscription: { unsubscribe: () => {} } },
        error: null
      }),
    },
    channel: (name: string) => ({
      on: () => ({
        subscribe: () => ({
          unsubscribe: () => {
            console.log(`Mock unsubscribe from ${name}`);
          }
        })
      })
    }),
  };
} else {
  // Create the real client when credentials are available
  supabase = createClient(supabaseUrl, supabaseAnonKey);
  console.log("Supabase client initialized successfully");
}

export { supabase };

export const insertData = async <T>(tableName: string, data: Partial<T>): Promise<T> => {
  if (!supabaseUrl || !supabaseAnonKey) {
    console.warn(`Cannot insert into ${tableName} - Supabase not configured`);
    throw new Error('Supabase not configured');
  }
  
  console.log(`Inserting data into table: ${tableName}`, data);
  
  try {
    const { data: insertedData, error } = await supabase
      .from(tableName)
      .insert(data)
      .select()
      .single();
    
    if (error) {
      console.error(`Error inserting into ${tableName}:`, error);
      throw error;
    }
    
    console.log(`Successfully inserted data into ${tableName}:`, insertedData);
    return insertedData as T;
  } catch (error) {
    console.error('Insertion failed:', error);
    throw error;
  }
};

export const fetchData = async <T>(tableName: string, query = {}): Promise<T[]> => {
  try {
    console.log(`Fetching data from ${tableName} with query:`, query);
    
    let queryBuilder = supabase.from(tableName).select('*');
    
    // Apply filters if query object has properties
    if (Object.keys(query).length > 0) {
      for (const [key, value] of Object.entries(query)) {
        queryBuilder = queryBuilder.eq(key, value);
      }
    }
    
    const { data, error } = await queryBuilder;
    
    if (error) {
      console.error(`Error fetching from ${tableName}:`, error);
      throw error;
    }
    
    console.log(`Successfully fetched ${data?.length || 0} records from ${tableName}`);
    return data as T[];
  } catch (error) {
    console.error(`Fetch from ${tableName} failed:`, error);
    return [];
  }
};

export const updateData = async <T>(tableName: string, id: string, updates: Partial<T>): Promise<T> => {
  try {
    console.log(`Updating record ${id} in ${tableName} with:`, updates);
    const { data, error } = await supabase
      .from(tableName)
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error(`Error updating ${tableName}:`, error);
      throw error;
    }
    
    console.log(`Successfully updated record in ${tableName}:`, data);
    return data as T;
  } catch (error) {
    console.error(`Update in ${tableName} failed:`, error);
    throw error;
  }
};

export const deleteData = async (tableName: string, id: string): Promise<void> => {
  try {
    console.log(`Deleting record ${id} from ${tableName}`);
    const { error } = await supabase.from(tableName).delete().eq('id', id);
    
    if (error) {
      console.error(`Error deleting from ${tableName}:`, error);
      throw error;
    }
    
    console.log(`Successfully deleted record ${id} from ${tableName}`);
  } catch (error) {
    console.error(`Deletion from ${tableName} failed:`, error);
    throw error;
  }
};

export const subscribeToTable = (tableName: string, callback: Function) => {
  try {
    console.log(`Setting up subscription for table ${tableName}`);
    const channel = supabase
      .channel(`${tableName}_changes`)
      .on('postgres_changes', { event: '*', schema: 'public', table: tableName }, (payload) => {
        console.log(`Received change in ${tableName}:`, payload);
        callback(payload);
      })
      .subscribe();
    
    console.log(`Subscription to ${tableName} active`);
    // Return the cleanup function directly
    return () => {
      console.log(`Unsubscribing from ${tableName}`);
      channel.unsubscribe();
    };
  } catch (error) {
    console.error(`Failed to subscribe to ${tableName}:`, error);
    return () => {};
  }
};
