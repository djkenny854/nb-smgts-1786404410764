import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/

/* nb-build-repair:exclude */
const __nbExcludePatterns = ["supabase/functions/**"];
function __nbIsExcluded(id) { return __nbExcludePatterns.some(p => id.includes(p.replace(/\*+/g, ""))); }

export default defineConfig(({ mode }) => ({
  build: { rollupOptions: { external: (id) => __nbIsExcluded(id) } },
  server: {
    host: "::",
    port: 8080,
  },
  plugins: [
    react(),
    mode === 'development' &&
    componentTagger(),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
